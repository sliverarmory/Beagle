"""
Long-lived worker that hosts the GraphQLite SQLite extension in a separate
process so a crash in the extension does not kill the whole harness.

Protocol (one JSON object per line on stdin, one JSON object per line on stdout):

    request:  {"cmd": "reset"}                      -> {"ok": true}
    request:  {"cmd": "execute", "query": "..."}    -> {"ok": true, "rows": ["..."]}
                                                       (rows are the raw cypher()
                                                        return payloads — the
                                                        comparator does its own
                                                        decoding)
                                                    -> {"ok": false, "error_class": "...",
                                                        "error_message": "..."}
    request:  {"cmd": "state"}                      -> {"ok": true, "nodes": [...], "rels": [...],
                                                        "labels": [...], "props": [...]}
                                                       (graph state, for side effects)
    request:  {"cmd": "shutdown"}                   -> {"ok": true}, then exit

The harness's `ExtensionBackend` supervises this worker and respawns it on
unclean exit (SIGSEGV, etc.), marking the in-flight scenario as `error`.
"""

from __future__ import annotations

import json
import re
import os
import resource
import signal
import sqlite3
import sys
import traceback
from pathlib import Path


DEFAULT_EXT = Path("build/graphqlite")


def _suppress_crash_reporter() -> None:
    """Stop the OS crash reporter from spawning a dialog for every
    extension SIGABRT/SIGSEGV. The harness already catches the worker
    death and records it as `ExtensionCrash`; the kernel-level crash
    log is just noise (and on macOS it pops a 'graphqlite crashed'
    notification per scenario, which makes iterative testing painful).

    Two layers of defense:
    1. Disable core dumps via RLIMIT_CORE — keeps disk + Crash Reporter
       cycles down.
    2. Re-raise SIGABRT as exit(134) via a signal handler — when the
       extension calls abort(), Python catches the signal first and
       exits cleanly with the conventional 128+SIGABRT code. macOS
       won't dispatch the abort to Crash Reporter because we already
       exited."""
    try:
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except (ValueError, OSError):
        pass
    def _die(signum, _frame):
        os._exit(128 + signum)
    for sig in (signal.SIGABRT, signal.SIGSEGV, signal.SIGBUS, signal.SIGFPE, signal.SIGILL):
        try:
            signal.signal(sig, _die)
        except (ValueError, OSError):
            pass


def main() -> int:
    _suppress_crash_reporter()
    ext_path = Path(os.environ.get("GQLITE_TCK_EXT", str(DEFAULT_EXT)))
    debug_log = os.environ.get("GQLITE_TCK_DEBUG_LOG")

    # Always redirect fds 1 and 2 away from the protocol channel: the
    # GRAPHQLITE_DEBUG-compiled extension prints to stdout via CYPHER_DEBUG
    # and to stderr from various places. If we left fd 1 inherited, that
    # debug noise would corrupt the JSON protocol the parent reads.
    if debug_log:
        Path(debug_log).parent.mkdir(parents=True, exist_ok=True)
        log_fd = os.open(debug_log, os.O_WRONLY | os.O_APPEND | os.O_CREAT)
    else:
        log_fd = os.open(os.devnull, os.O_WRONLY)
    protocol_out = os.dup(1)
    os.dup2(log_fd, 1)
    os.dup2(log_fd, 2)
    os.close(log_fd)
    proto = os.fdopen(protocol_out, "w", buffering=1)

    conn = _new_conn(ext_path)

    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError as e:
            _write(proto, {"ok": False, "error_class": "ProtocolError", "error_message": str(e)})
            continue

        cmd = req.get("cmd")
        try:
            if cmd == "reset":
                conn.close()
                conn = _new_conn(ext_path)
                _write(proto, {"ok": True})
            elif cmd == "execute":
                params = req.get("parameters")
                if params:
                    params_json = json.dumps(params)
                    raw = conn.execute("SELECT cypher(?, ?)",
                                       (req.get("query", ""), params_json)).fetchall()
                else:
                    raw = conn.execute("SELECT cypher(?)", (req.get("query", ""),)).fetchall()
                _write(proto, _decode_payload([r[0] for r in raw]))
            elif cmd == "state":
                _write(proto, dict(ok=True, **_graph_state(conn)))
            elif cmd == "shutdown":
                conn.close()
                _write(proto, {"ok": True})
                return 0
            else:
                _write(proto, {"ok": False, "error_class": "ProtocolError",
                               "error_message": f"unknown cmd: {cmd!r}"})
        except sqlite3.Error as e:
            _write(proto, {"ok": False, "error_class": _classify(str(e)),
                           "error_message": str(e)})
        except Exception:
            _write(proto, {"ok": False, "error_class": "WorkerError",
                           "error_message": traceback.format_exc()})

    return 0


def _decode_payload(raw_payloads: list) -> dict:
    """
    Decode the extension's `cypher()` return into the harness wire format:

        {"ok": True, "columns": [...], "rows": [[v0, v1, ...], ...]}

    `cypher()` returns one SQLite row whose single TEXT column is one of:
      - a JSON array of column-keyed objects: '[{"name":"Alice"}, ...]'  → result set
      - a write-statistics object: '{"nodes_created":N,"relationships_created":N,
        "nodes_deleted":N,"relationships_deleted":N,"properties_set":N}'
        (treat as 0 data rows; reported verbatim in `status`)
      - the literal '[]' for empty result sets
      - a JSON error object: '{"error":"...","code":"..."}'  → surfaced upstream
    """
    if not raw_payloads:
        return {"ok": True, "columns": [], "rows": []}

    # `cypher()` always returns exactly one row, but defend against future
    # multi-row returns by concatenating their decoded forms.
    columns: list = []
    rows: list = []
    status: str | None = None

    for payload in raw_payloads:
        if payload is None:
            continue
        text = payload if isinstance(payload, str) else str(payload)
        text_stripped = text.strip()
        # Try JSON first.
        try:
            decoded = json.loads(text_stripped) if text_stripped else None
        except json.JSONDecodeError:
            decoded = None

        if decoded is None or (isinstance(decoded, str)):
            # Not JSON — treat as a status / mutation summary, not data.
            status = text
            continue

        if isinstance(decoded, list):
            # Result set: list of {col: value} objects.
            for item in decoded:
                if isinstance(item, dict):
                    if not columns:
                        columns = list(item.keys())
                    rows.append([item.get(c) for c in columns])
                else:
                    # Defensive: a scalar in the list — keep as single-cell row.
                    if not columns:
                        columns = ["value"]
                    rows.append([item])
        elif isinstance(decoded, dict) and "error" in decoded:
            return {"ok": False,
                    "error_class": _classify(text),
                    "error_message": decoded.get("error", text)}
        elif isinstance(decoded, dict) and "nodes_created" in decoded:
            # Write-statistics object for a RETURN-less mutation: not data.
            status = text
            continue
        elif isinstance(decoded, dict):
            # Single-row object.
            if not columns:
                columns = list(decoded.keys())
            rows.append([decoded.get(c) for c in columns])

    out = {"ok": True, "columns": columns, "rows": rows}
    if status:
        out["status"] = status
    return out


_PROP_TABLES = ("int", "real", "text", "bool", "json")


def _graph_state(conn: sqlite3.Connection) -> dict:
    """The graph as sets the TCK diffs for side effects: node ids,
    relationship ids, the label names in use, and (entity, key, value)
    property triples. Empty before the first query creates the tables."""
    have = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if "nodes" not in have:
        return {"nodes": [], "rels": [], "labels": [], "props": []}
    nodes = [r[0] for r in conn.execute("SELECT id FROM nodes")]
    rels = [r[0] for r in conn.execute("SELECT id FROM edges")]
    labels = [r[0] for r in conn.execute("SELECT DISTINCT label FROM node_labels")]
    props = []
    for kind, col in (("node", "node_id"), ("edge", "edge_id")):
        for t in _PROP_TABLES:
            table = f"{kind}_props_{t}"
            if table not in have:
                continue
            for eid, key, value in conn.execute(
                    f"SELECT p.{col}, k.key, p.value FROM {table} p JOIN property_keys k ON k.id = p.key_id"):
                props.append([kind, eid, key, t, value])
    return {"nodes": nodes, "rels": rels, "labels": labels, "props": props}


def _new_conn(ext_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.enable_load_extension(True)
    conn.load_extension(str(ext_path))
    _install_deterministic_random(conn)
    return conn


def _install_deterministic_random(conn: sqlite3.Connection) -> None:
    """Override SQLite's built-in random() with a deterministic LCG so
    that TCK scenarios using `rand()` (which transforms to
    `ABS(RANDOM())/...`) produce the same sequence every run.

    Several openCypher Quantifier and Comprehension scenarios test
    tautologies of the form `any(P) = NOT all(NOT P)` while feeding
    `rand()`-shuffled input lists. They're meant to be invariant
    regardless of input — but a real bug in our implementation
    surfaces only on certain inputs, so the flake hides it. Making
    rand() deterministic per-connection turns the flake into a
    consistent signal: either the test now consistently passes (no
    real bug for this seed) or consistently fails (and we can
    investigate the deterministic counterexample).

    Seed is fixed; sequence resets when the harness creates a new
    connection (i.e. between scenarios). LCG constants from Numerical
    Recipes — full int64 cycle, no zero output."""
    state = [0x5DEECE66D9F37C45]  # arbitrary fixed seed

    def _random() -> int:
        state[0] = (state[0] * 6364136223846793005 + 1442695040888963407) & 0xFFFFFFFFFFFFFFFF
        # SQLite's random() returns a signed 64-bit; map our unsigned state
        # into the signed range so ABS(RANDOM()) behaves as the extension
        # expects.
        v = state[0]
        return v - (1 << 64) if v >= (1 << 63) else v

    conn.create_function("random", 0, _random, deterministic=True)


def _named_graph_file(name: str) -> Path | None:
    """TCK named-graph fixture: vendor/tck/graphs/<name>/<name>.cypher (preferred)
    falls back to cypher.cyp for legacy layout."""
    root = Path("vendor/tck/graphs") / name
    for candidate in (root / f"{name}.cypher", root / "cypher.cyp"):
        if candidate.exists():
            return candidate
    return None


def _write(proto, msg: dict) -> None:
    proto.write(json.dumps(msg) + "\n")
    proto.flush()


_ERROR_CLASS_PREFIX = re.compile(r"^(\w+(?:Error|Failed|Failure|NotFound|Missing)):")


def _classify(msg: str) -> str:
    """The openCypher error class of an engine error, strictly: the class
    the engine names at the start of the message ("TypeError: ...",
    "EntityNotFound: DeletedEntityAccess: ..."), or SyntaxError for a parse
    error. Anything else is unclassified (GraphQLiteError): the harness
    does not guess a class from words in the message (GQLITE-T-0429)."""
    text = (msg or "").strip()
    code = ""
    if text.startswith("{"):
        try:
            obj = json.loads(text)
            text = str(obj.get("error", ""))
            code = str(obj.get("code", ""))
        except (json.JSONDecodeError, AttributeError):
            pass
    m = _ERROR_CLASS_PREFIX.match(text.lstrip())
    if m:
        return m.group(1)
    if code == "PARSE_ERROR" or text == "PARSE_ERROR":
        return "SyntaxError"
    return "GraphQLiteError"


if __name__ == "__main__":
    sys.exit(main())
