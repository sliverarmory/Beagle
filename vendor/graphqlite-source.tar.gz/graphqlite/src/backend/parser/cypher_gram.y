%{
/*
 * Cypher Grammar for GraphQLite
 * Simplified version based on Apache AGE grammar for SQLite compatibility
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "parser/cypher_ast.h"
#include "parser/cypher_parser.h"

/* Forward declarations */
void cypher_yyerror(CYPHER_YYLTYPE *yylloc, cypher_parser_context *context, const char *msg);
int cypher_yylex(CYPHER_YYSTYPE *yylval, CYPHER_YYLTYPE *yylloc, cypher_parser_context *context);

%}

%code requires {
#include <stdint.h>
#include <stdbool.h>
}

%code {
/* The source text from (line, col) to (last_line, last_col), both
 * 1-based and inclusive, trimmed. NULL when the input cannot be read. */
static char *source_text_span(cypher_parser_context *context, int line, int col,
                              int last_line, int last_col)
{
    const char *in = (context && context->scanner) ? context->scanner->input_string : NULL;
    if (!in || line < 1 || col < 1 || last_line < line) return NULL;
    const char *p = in;
    for (int l = 1; l < line && *p; p++) if (*p == '\n') l++;
    for (int c = 1; c < col && *p && *p != '\n'; c++) p++;
    const char *q = p;
    int l = line, c = col;
    while (*q && (l < last_line || (l == last_line && c < last_col))) {
        if (*q == '\n') { l++; c = 1; } else c++;
        q++;
    }
    if (*q) q++;   /* inclusive end */
    while (p < q && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    while (q > p && (q[-1] == ' ' || q[-1] == '\t' || q[-1] == '\n' || q[-1] == '\r')) q--;
    if (q <= p) return NULL;
    return strndup(p, (size_t)(q - p));
}

/* The spelling of a keyword as written, at `line` / `col` (1-based) of the
 * input, for a keyword used as a map key: `{NULL: 1}` keeps the key "NULL"
 * (the scanner upper-cases keywords; Map1 [5], Map2 [5]). `fallback` when
 * the input cannot be read. Owned by the caller. */
static char *keyword_text_at(cypher_parser_context *context, int line, int col,
                             const char *fallback)
{
    const char *in = (context && context->scanner) ? context->scanner->input_string : NULL;
    if (!in || line < 1 || col < 1) return strdup(fallback);
    for (int l = 1; l < line && *in; in++) if (*in == '\n') l++;
    for (int c = 1; c < col && *in && *in != '\n'; c++) in++;
    size_t n = 0;
    while (in[n] && ((in[n] >= 'A' && in[n] <= 'Z') || (in[n] >= 'a' && in[n] <= 'z') ||
                     in[n] == '_' || (in[n] >= '0' && in[n] <= '9'))) n++;
    if (n == 0 || strncasecmp(in, fallback, n) != 0 || strlen(fallback) != n) return strdup(fallback);
    return strndup(in, n);
}
}

%locations
%define api.pure
%define api.prefix {cypher_yy}
%define api.token.prefix {CYPHER_}
%define parse.error detailed
%glr-parser
%parse-param {cypher_parser_context *context}
%lex-param {cypher_parser_context *context}

/*
 * Expected grammar conflicts - handled correctly by GLR parsing.
 * These arise from pattern comprehension syntax [(...)-[r]->(...) | expr]
 * and pattern predicates (n)-[:REL]->() in boolean context, where the
 * parser can't immediately distinguish a node pattern from a parenthesized
 * expression until it sees more context (e.g., a following rel_pattern).
 */
%expect 13
%expect-rr 3  /* IDENTIFIER, BQIDENT, END_P in variable_opt */

%union {
    int64_t integer;
    double decimal;
    char *string;
    bool boolean;
    
    /* AST node types */
    ast_node *node;
    ast_list *list;
    
    /* Specific node types for type safety */
    cypher_query *query;
    cypher_match *match;
    cypher_return *return_clause;
    cypher_create *create;
    cypher_merge *merge;
    cypher_set *set;
    cypher_set_item *set_item;
    cypher_delete *delete;
    cypher_delete_item *delete_item;
    cypher_remove *remove;
    cypher_remove_item *remove_item;
    cypher_with *with_clause;
    cypher_union *union_query;
    cypher_return_item *return_item;
    cypher_order_by_item *order_by_item;
    cypher_literal *literal;
    cypher_identifier *identifier;
    cypher_parameter *parameter;
    cypher_label_expr *label_expr;
    cypher_not_expr *not_expr;
    cypher_binary_op *binary_op;
    cypher_exists_expr *exists_expr;
    cypher_node_pattern *node_pattern;
    cypher_rel_pattern *rel_pattern;
    cypher_varlen_range *varlen_range;
    cypher_path *path;
    cypher_map *map;
    cypher_map_pair *map_pair;
    cypher_list_comprehension *list_comprehension;
}

/* Terminal tokens */
%token <integer> INTEGER
%token <decimal> DECIMAL
%token <string> STRING IDENTIFIER PARAMETER BQIDENT

/* Multi-character operators */
%token NOT_EQ LT_EQ GT_EQ DOT_DOT TYPECAST PLUS_EQ REGEX_MATCH

/* Keywords */
%token MATCH RETURN CREATE WHERE WITH SET DELETE REMOVE MERGE UNWIND DETACH FOREACH CALL YIELD
%token OPTIONAL DISTINCT ORDER BY SKIP LIMIT AS ASC DESC
%token AND OR XOR NOT IN IS NULL_P TRUE_P FALSE_P EXISTS
%token ANY NONE SINGLE REDUCE
%token UNION ALL CASE WHEN THEN ELSE END_P ON
%token SHORTESTPATH ALLSHORTESTPATHS PATTERN EXPLAIN
%token LOAD CSV FROM HEADERS FIELDTERMINATOR
%token STARTS ENDS CONTAINS

/* Non-terminal types */
%type <node> stmt union_query single_query
%type <list> clause_list
%type <node> clause

%type <match> match_clause
%type <return_clause> return_clause
%type <create> create_clause
%type <merge> merge_clause
%type <set> set_clause
%type <delete> delete_clause
%type <remove> remove_clause
%type <with_clause> with_clause
%type <node> unwind_clause foreach_clause call_clause conditional_clause load_csv_clause list_literal list_comprehension pattern_comprehension map_literal map_projection map_projection_item case_expression when_clause
%type <list> map_projection_list foreach_update_list
%type <list> when_clause_list on_create_clause on_match_clause

%type <list> pattern_list return_item_list set_item_list delete_item_list remove_item_list
%type <set_item> set_item
%type <delete_item> delete_item
%type <string> procedure_name qualified_function_name
%type <list> proc_args_opt yield_item_list call_import_list
%type <return_item> yield_item call_import_item
%type <remove_item> remove_item
%type <boolean> detach_opt
%type <path> path simple_path
%type <node_pattern> node_pattern
%type <rel_pattern> rel_pattern
%type <varlen_range> varlen_range_opt
%type <return_item> return_item

%type <node> expr primary_expr literal_expr function_call list_predicate reduce_expr set_target
%type <list> argument_list
%type <literal> literal
%type <identifier> identifier
%type <parameter> parameter
%type <map> properties_opt
%type <map_pair> map_pair
%type <list> map_pair_list

%type <list> label_opt label_list label_alt_list
%type <string> label_name
%type <string> variable_opt from_graph_opt non_reserved_kw
%type <boolean> optional_opt distinct_opt
%type <list> order_by_opt order_by_list rel_type_list
%type <node> skip_opt limit_opt where_opt
%type <order_by_item> order_by_item

/* Operator precedence (lowest to highest) */
%left OR
%left XOR
%left AND
%right NOT
%left '=' NOT_EQ '<' LT_EQ '>' GT_EQ REGEX_MATCH
/* openCypher: string, list and null predicates bind tighter than comparison
 * and looser than arithmetic: `[1]+2 IN [3]+4` is `([1]+2) IN ([3]+4)`
 * (Precedence3 [4]/[5]). */
%left IN IS STARTS ENDS CONTAINS
%left '+' '-'
%left '*' '/' '%'
%left '^'
%left '.' '['
/* Unary -/+ bind tightest among arithmetic: `-3^2` = (-3)^2 = 9
 * (Precedence2 [4]). Negation of a non-literal is materialized as 0 - expr
 * in the '-' expr production. */
%right UNARY_MINUS UNARY_PLUS

%%

/* Main grammar rules */

stmt:
    union_query
        {
            $$ = $1;
            context->result = $1;
        }
    | union_query ';'
        {
            $$ = $1;
            context->result = $1;
        }
    | EXPLAIN union_query
        {
            /* For EXPLAIN with UNION, wrap if needed */
            if ($2->type == AST_NODE_QUERY) {
                ((cypher_query*)$2)->explain = true;
            }
            $$ = $2;
            context->result = $2;
        }
    | EXPLAIN union_query ';'
        {
            if ($2->type == AST_NODE_QUERY) {
                ((cypher_query*)$2)->explain = true;
            }
            $$ = $2;
            context->result = $2;
        }
    ;

union_query:
    single_query
        {
            $$ = $1;
        }
    | union_query UNION single_query
        {
            $$ = (ast_node*)make_cypher_union($1, $3, false, @2.first_line);
        }
    | union_query UNION ALL single_query
        {
            $$ = (ast_node*)make_cypher_union($1, $4, true, @2.first_line);
        }
    ;

single_query:
    clause_list
        {
            $$ = (ast_node*)make_cypher_query($1, false);
        }
    ;

clause_list:
    clause
        {
            $$ = ast_list_create();
            ast_list_append($$, $1);
        }
    | clause_list clause
        {
            ast_list_append($1, $2);
            $$ = $1;
        }
    ;

clause:
    match_clause        { $$ = (ast_node*)$1; }
    | return_clause     { $$ = (ast_node*)$1; }
    | with_clause       { $$ = (ast_node*)$1; }
    | unwind_clause     { $$ = $1; }
    | foreach_clause    { $$ = $1; }
    | load_csv_clause   { $$ = $1; }
    | create_clause     { $$ = (ast_node*)$1; }
    | merge_clause      { $$ = (ast_node*)$1; }
    | set_clause        { $$ = (ast_node*)$1; }
    | delete_clause     { $$ = (ast_node*)$1; }
    | remove_clause     { $$ = (ast_node*)$1; }
    | call_clause       { $$ = $1; }
    | conditional_clause { $$ = $1; }
    ;

/* MATCH clause */
match_clause:
    optional_opt MATCH pattern_list from_graph_opt where_opt
        {
            $$ = make_cypher_match($3, $5, $1, $4);
        }
    ;

from_graph_opt:
    /* empty */     { $$ = NULL; }
    | FROM IDENTIFIER
        {
            $$ = $2;
        }
    ;

optional_opt:
    /* empty */     { $$ = false; }
    | OPTIONAL      { $$ = true; }
    ;

/* RETURN clause */
return_clause:
    RETURN distinct_opt return_item_list order_by_opt skip_opt limit_opt
        {
            $$ = make_cypher_return($2, $3, $4, $5, $6);
        }
    | RETURN '*' order_by_opt skip_opt limit_opt
        {
            /* RETURN * - return all bound variables (items=NULL signals star) */
            $$ = make_cypher_return(false, NULL, $3, $4, $5);
        }
    | RETURN DISTINCT '*' order_by_opt skip_opt limit_opt
        {
            $$ = make_cypher_return(true, NULL, $4, $5, $6);
        }
    ;

/* WITH clause - projection with optional WHERE for filtering */
with_clause:
    WITH distinct_opt return_item_list order_by_opt skip_opt limit_opt where_opt
        {
            $$ = make_cypher_with($2, $3, $4, $5, $6, $7);
        }
    | WITH '*' order_by_opt skip_opt limit_opt where_opt
        {
            /* WITH * - pass all variables through */
            $$ = make_cypher_with(false, NULL, $3, $4, $5, $6);
        }
    ;

/* UNWIND clause - expands list into rows */
unwind_clause:
    UNWIND expr AS IDENTIFIER
        {
            $$ = (ast_node*)make_cypher_unwind($2, $4, @1.first_line);
            free($4);
        }
    | UNWIND expr AS BQIDENT
        {
            /* Backtick-quoted alias (scanner stripped the backticks). */
            $$ = (ast_node*)make_cypher_unwind($2, $4, @1.first_line);
            free($4);
        }
    ;

/* FOREACH clause - iterate over list and apply update clauses */
foreach_clause:
    FOREACH '(' IDENTIFIER IN expr '|' foreach_update_list ')'
        {
            $$ = (ast_node*)make_cypher_foreach($3, $5, $7, @1.first_line);
            free($3);
        }
    | FOREACH '(' BQIDENT IN expr '|' foreach_update_list ')'
        {
            /* T-0329: backtick-quoted loop variable. */
            $$ = (ast_node*)make_cypher_foreach($3, $5, $7, @1.first_line);
            free($3);
        }
    ;

/* CALL {} subquery clause
 * The inner query uses union_query which already handles UNION/UNION ALL chaining.
 * Each UNION branch is stored in the AST via the existing cypher_union structure.
 * The call_subquery node wraps the inner query (single or union chain) in a branches list.
 */
call_clause:
    CALL '{' union_query '}'
        {
            ast_list *branches = ast_list_create();
            ast_list_append(branches, $3);
            $$ = (ast_node*)make_cypher_call_subquery(branches, @1.first_line);
        }
    | CALL '(' call_import_list ')' '{' union_query '}'
        {
            ast_list *branches = ast_list_create();
            ast_list_append(branches, $6);
            cypher_call_subquery *call = make_cypher_call_subquery(branches, @1.first_line);
            call->explicit_scope = true;
            call->imports = ast_list_create();
            call->import_projections = ast_list_create();
            for (int i = 0; i < $3->count; i++) {
                cypher_return_item *item = (cypher_return_item*)$3->items[i];
                if (item->alias) {
                    ast_list_append(call->import_projections, (ast_node*)item);
                } else {
                    ast_list_append(call->imports, item->expr);
                    item->expr = NULL;
                    ast_node_free((ast_node*)item);
                }
                $3->items[i] = NULL;
            }
            ast_list_free($3);
            $$ = (ast_node*)call;
        }
    | CALL '(' '*' ')' '{' union_query '}'
        {
            ast_list *branches = ast_list_create();
            ast_list_append(branches, $6);
            cypher_call_subquery *call = make_cypher_call_subquery(branches, @1.first_line);
            call->explicit_scope = true;
            call->import_all = true;
            $$ = (ast_node*)call;
        }
    | CALL '(' ')' '{' union_query '}'
        {
            ast_list *branches = ast_list_create();
            ast_list_append(branches, $5);
            cypher_call_subquery *call = make_cypher_call_subquery(branches, @1.first_line);
            call->explicit_scope = true;
            $$ = (ast_node*)call;
        }
    | CALL procedure_name proc_args_opt
        {
            /* `CALL pageRank()`: the graph algorithms are procedures; any
             * other name is ProcedureNotFound at run time (GQLITE-T-0389). */
            $$ = (ast_node*)make_cypher_call_procedure($2, $3, NULL, false, NULL, @1.first_line);
            free($2);
        }
    | CALL procedure_name proc_args_opt YIELD '*'
        {
            $$ = (ast_node*)make_cypher_call_procedure($2, $3, NULL, true, NULL, @1.first_line);
            free($2);
        }
    | CALL procedure_name proc_args_opt YIELD yield_item_list
        {
            $$ = (ast_node*)make_cypher_call_procedure($2, $3, $5, false, NULL, @1.first_line);
            free($2);
        }
    | CALL procedure_name proc_args_opt YIELD yield_item_list WHERE expr
        {
            $$ = (ast_node*)make_cypher_call_procedure($2, $3, $5, false, $7, @1.first_line);
            free($2);
        }
    ;

call_import_list:
    call_import_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | call_import_list ',' call_import_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

call_import_item:
    identifier
        { $$ = make_return_item((ast_node*)$1, NULL); }
    | expr AS IDENTIFIER
        {
            /* Cirro compatibility extension: evaluate a projected import
             * in the outer row, then make its alias local to the subquery. */
            $$ = make_return_item($1, $3);
            free($3);
        }
    | expr AS BQIDENT
        {
            $$ = make_return_item($1, $3);
            free($3);
        }
    ;

/* A conditional update query is a unit subquery whose first projection
 * filters its input row. Keeping it a CALL preserves the outer row when
 * the condition is false/null, including between independent branches. */
conditional_clause:
    WHEN expr THEN '{' clause_list '}'
        {
            ast_list *body = ast_list_create();
            ast_list_append(body, (ast_node*)make_cypher_with(false, NULL, NULL, NULL, NULL, $2));
            for (int i = 0; i < $5->count; i++) {
                ast_list_append(body, $5->items[i]);
                $5->items[i] = NULL;
            }
            ast_list_free($5);
            ast_list *branches = ast_list_create();
            ast_list_append(branches, (ast_node*)make_cypher_query(body, false));
            cypher_call_subquery *call = make_cypher_call_subquery(branches, @1.first_line);
            call->explicit_scope = true;
            call->import_all = true;
            $$ = (ast_node*)call;
        }
    ;

proc_args_opt:
    /* empty: no parentheses */  { $$ = NULL; }
    | '(' ')'                    { $$ = ast_list_create(); }
    | '(' argument_list ')'      { $$ = $2; }
    ;

yield_item_list:
    yield_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | yield_item_list ',' yield_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

yield_item:
    IDENTIFIER
        {
            $$ = make_return_item((ast_node*)make_identifier($1, @1.first_line), $1);
            free($1);
        }
    | IDENTIFIER AS IDENTIFIER
        {
            $$ = make_return_item((ast_node*)make_identifier($1, @1.first_line), $3);
            free($1);
            free($3);
        }
    ;

procedure_name:
    IDENTIFIER
        { $$ = $1; }
    | procedure_name '.' label_name
        {
            size_t n = strlen($1) + strlen($3) + 2;
            $$ = malloc(n);
            snprintf($$, n, "%s.%s", $1, $3);
            free($1);
            free($3);
        }
    ;

/* LOAD CSV clause - import data from CSV files */
load_csv_clause:
    LOAD CSV FROM STRING AS IDENTIFIER
        {
            $$ = (ast_node*)make_cypher_load_csv($4, $6, false, NULL, @1.first_line);
            free($4);
            free($6);
        }
    | LOAD CSV WITH HEADERS FROM STRING AS IDENTIFIER
        {
            $$ = (ast_node*)make_cypher_load_csv($6, $8, true, NULL, @1.first_line);
            free($6);
            free($8);
        }
    | LOAD CSV FROM STRING AS IDENTIFIER FIELDTERMINATOR STRING
        {
            $$ = (ast_node*)make_cypher_load_csv($4, $6, false, $8, @1.first_line);
            free($4);
            free($6);
            free($8);
        }
    | LOAD CSV WITH HEADERS FROM STRING AS IDENTIFIER FIELDTERMINATOR STRING
        {
            $$ = (ast_node*)make_cypher_load_csv($6, $8, true, $10, @1.first_line);
            free($6);
            free($8);
            free($10);
        }
    ;

/* Update clauses allowed inside FOREACH: CREATE, SET, DELETE, MERGE, REMOVE, FOREACH */
foreach_update_list:
    create_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | set_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | delete_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | merge_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | remove_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | foreach_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, $1);
        }
    | foreach_update_list create_clause
        {
            ast_list_append($1, (ast_node*)$2);
            $$ = $1;
        }
    | foreach_update_list set_clause
        {
            ast_list_append($1, (ast_node*)$2);
            $$ = $1;
        }
    | foreach_update_list delete_clause
        {
            ast_list_append($1, (ast_node*)$2);
            $$ = $1;
        }
    | foreach_update_list merge_clause
        {
            ast_list_append($1, (ast_node*)$2);
            $$ = $1;
        }
    | foreach_update_list remove_clause
        {
            ast_list_append($1, (ast_node*)$2);
            $$ = $1;
        }
    | foreach_update_list foreach_clause
        {
            ast_list_append($1, $2);
            $$ = $1;
        }
    ;

distinct_opt:
    /* empty */     { $$ = false; }
    | DISTINCT      { $$ = true; }
    ;

order_by_opt:
    /* empty */     { $$ = NULL; }
    | ORDER BY order_by_list { $$ = $3; }
    ;

skip_opt:
    /* empty */     { $$ = NULL; }
    | SKIP expr     { $$ = $2; }
    ;

limit_opt:
    /* empty */     { $$ = NULL; }
    | LIMIT expr    { $$ = $2; }
    ;

where_opt:
    /* empty */     { $$ = NULL; }
    | WHERE expr    { $$ = $2; }
    ;

order_by_list:
    order_by_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | order_by_list ',' order_by_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

order_by_item:
    expr            { $$ = make_order_by_item($1, false); /* Default is ASC */ }
    | expr ASC      { $$ = make_order_by_item($1, false); }
    | expr DESC     { $$ = make_order_by_item($1, true); }
    ;


return_item_list:
    return_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | return_item_list ',' return_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

return_item:
    expr
        {
            $$ = make_return_item($1, NULL);
            /* The column of an unaliased item is named as written
             * (`count( * )`, `n.missing IS NULL`). */
            if ($$) $$->source_text = source_text_span(context, @1.first_line, @1.first_column,
                                                       @1.last_line, @1.last_column);
        }
    | expr AS IDENTIFIER
        {
            $$ = make_return_item($1, $3);
            free($3);
        }
    | expr AS BQIDENT
        {
            /* Backtick-quoted alias (e.g. RETURN x AS `name`) — the
             * scanner has already stripped the surrounding backticks.
             * Same shape as IDENTIFIER. */
            $$ = make_return_item($1, $3);
            free($3);
        }
    ;

set_item_list:
    set_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | set_item_list ',' set_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* SET n:L1:L2 — produce two set_items, one per label. */
            $$ = ast_list_create();
            {
              cypher_identifier *v1 = make_identifier($1, @1.first_line);
              cypher_label_expr *l1 = make_label_expr((ast_node*)v1, $3, @3.first_line);
              ast_list_append($$, (ast_node*)make_cypher_set_item((ast_node*)l1, NULL, false));
            }
            {
              cypher_identifier *v2 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l2 = make_label_expr((ast_node*)v2, $5, @5.first_line);
              ast_list_append($$, (ast_node*)make_cypher_set_item((ast_node*)l2, NULL, false));
            }
            free($1);
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* SET n:L1:L2:L3 — three labels. */
            $$ = ast_list_create();
            {
              cypher_identifier *v1 = make_identifier($1, @1.first_line);
              cypher_label_expr *l1 = make_label_expr((ast_node*)v1, $3, @3.first_line);
              ast_list_append($$, (ast_node*)make_cypher_set_item((ast_node*)l1, NULL, false));
            }
            {
              cypher_identifier *v2 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l2 = make_label_expr((ast_node*)v2, $5, @5.first_line);
              ast_list_append($$, (ast_node*)make_cypher_set_item((ast_node*)l2, NULL, false));
            }
            {
              cypher_identifier *v3 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l3 = make_label_expr((ast_node*)v3, $7, @7.first_line);
              ast_list_append($$, (ast_node*)make_cypher_set_item((ast_node*)l3, NULL, false));
            }
            free($1);
        }
    ;

/* The target of SET x = ... / SET x += ...: a variable or a property of
 * one. Not a full expression, so `SET n.b = n.num > 2` reads the
 * comparison as the value (GQLITE-T-0407). */
set_target:
    identifier                     { $$ = (ast_node*)$1; }
    | '(' expr ')'                 { $$ = $2; if ($$) $$->parenthesized = true; }
    | set_target '.' IDENTIFIER
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | set_target '.' BQIDENT
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | set_target '.' non_reserved_kw
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | set_target '[' expr ']'
        {
            $$ = (ast_node*)make_subscript($1, $3, @2.first_line);
        }
    ;

set_item:
    set_target '=' expr
        {
            $$ = make_cypher_set_item($1, $3, false);
        }
    | set_target PLUS_EQ expr
        {
            /* SET n += {map} — merge properties */
            $$ = make_cypher_set_item($1, $3, true);
        }
    | IDENTIFIER ':' IDENTIFIER
        {
            /* SET n:Label syntax */
            cypher_identifier *var = make_identifier($1, @1.first_line);
            cypher_label_expr *label = make_label_expr((ast_node*)var, $3, @3.first_line);
            $$ = make_cypher_set_item((ast_node*)label, NULL, false);
            free($1);
            free($3);
        }
    ;

/* CREATE clause */
create_clause:
    CREATE pattern_list
        {
            $$ = make_cypher_create($2);
        }
    ;

/* MERGE clause */
merge_clause:
    MERGE pattern_list
        {
            $$ = make_cypher_merge($2, NULL, NULL);
        }
    | MERGE pattern_list on_create_clause
        {
            $$ = make_cypher_merge($2, $3, NULL);
        }
    | MERGE pattern_list on_match_clause
        {
            $$ = make_cypher_merge($2, NULL, $3);
        }
    | MERGE pattern_list on_create_clause on_match_clause
        {
            $$ = make_cypher_merge($2, $3, $4);
        }
    | MERGE pattern_list on_match_clause on_create_clause
        {
            $$ = make_cypher_merge($2, $4, $3);
        }
    ;

on_create_clause:
    ON CREATE SET set_item_list
        {
            $$ = $4;
        }
    ;

on_match_clause:
    ON MATCH SET set_item_list
        {
            $$ = $4;
        }
    ;

/* SET clause */
set_clause:
    SET set_item_list
        {
            $$ = make_cypher_set($2);
        }
    ;

/* DELETE clause */
delete_clause:
    detach_opt DELETE delete_item_list
        {
            $$ = make_cypher_delete($3, $1);
        }
    ;

delete_item_list:
    delete_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | delete_item_list ',' delete_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

delete_item:
    expr
        {
            /* `DELETE n`, or an expression: `DELETE list[0]`, `DELETE m.key`. */
            $$ = make_delete_item_expr($1);
        }
    ;

/* REMOVE clause */
remove_clause:
    REMOVE remove_item_list
        {
            $$ = make_cypher_remove($2);
        }
    ;

remove_item_list:
    remove_item
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | remove_item_list ',' remove_item
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* REMOVE n:L1:L2 — produce two remove_items, one per label. */
            $$ = ast_list_create();
            {
              cypher_identifier *v1 = make_identifier($1, @1.first_line);
              cypher_label_expr *l1 = make_label_expr((ast_node*)v1, $3, @3.first_line);
              ast_list_append($$, (ast_node*)make_remove_item((ast_node*)l1));
            }
            {
              cypher_identifier *v2 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l2 = make_label_expr((ast_node*)v2, $5, @5.first_line);
              ast_list_append($$, (ast_node*)make_remove_item((ast_node*)l2));
            }
            free($1);
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* REMOVE n:L1:L2:L3 — three labels. */
            $$ = ast_list_create();
            {
              cypher_identifier *v1 = make_identifier($1, @1.first_line);
              cypher_label_expr *l1 = make_label_expr((ast_node*)v1, $3, @3.first_line);
              ast_list_append($$, (ast_node*)make_remove_item((ast_node*)l1));
            }
            {
              cypher_identifier *v2 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l2 = make_label_expr((ast_node*)v2, $5, @5.first_line);
              ast_list_append($$, (ast_node*)make_remove_item((ast_node*)l2));
            }
            {
              cypher_identifier *v3 = make_identifier(strdup($1), @1.first_line);
              cypher_label_expr *l3 = make_label_expr((ast_node*)v3, $7, @7.first_line);
              ast_list_append($$, (ast_node*)make_remove_item((ast_node*)l3));
            }
            free($1);
        }
    ;

remove_item:
    IDENTIFIER '.' IDENTIFIER
        {
            /* REMOVE n.property - property access */
            cypher_identifier *base = make_identifier($1, @1.first_line);
            ast_node *prop = (ast_node*)make_property((ast_node*)base, $3, @3.first_line);
            $$ = make_remove_item(prop);
            free($1);
            free($3);
        }
    | IDENTIFIER '.' BQIDENT
        {
            /* REMOVE n.`special-key` - backtick-quoted property */
            cypher_identifier *base = make_identifier($1, @1.first_line);
            ast_node *prop = (ast_node*)make_property((ast_node*)base, $3, @3.first_line);
            $$ = make_remove_item(prop);
            free($1);
            free($3);
        }
    | BQIDENT '.' IDENTIFIER
        {
            /* REMOVE `special-var`.property */
            cypher_identifier *base = make_identifier($1, @1.first_line);
            ast_node *prop = (ast_node*)make_property((ast_node*)base, $3, @3.first_line);
            $$ = make_remove_item(prop);
            free($1);
            free($3);
        }
    | BQIDENT '.' BQIDENT
        {
            /* REMOVE `special-var`.`special-key` */
            cypher_identifier *base = make_identifier($1, @1.first_line);
            ast_node *prop = (ast_node*)make_property((ast_node*)base, $3, @3.first_line);
            $$ = make_remove_item(prop);
            free($1);
            free($3);
        }
    | IDENTIFIER ':' IDENTIFIER
        {
            /* REMOVE n:Label syntax */
            cypher_identifier *var = make_identifier($1, @1.first_line);
            cypher_label_expr *label = make_label_expr((ast_node*)var, $3, @3.first_line);
            $$ = make_remove_item((ast_node*)label);
            free($1);
            free($3);
        }
    ;

detach_opt:
    DETACH
        {
            $$ = true;
        }
    | /* EMPTY */
        {
            $$ = false;
        }
    ;

/* Pattern matching */
pattern_list:
    path
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | pattern_list ',' path
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

/* Simple path - base path without shortestPath wrappers */
simple_path:
    node_pattern
        {
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)$1);
            $$ = make_path(elements);
        }
    | simple_path rel_pattern node_pattern
        {
            /* Create a new list copying elements from the existing path */
            ast_list *new_elements = ast_list_create();
            for (int i = 0; i < $1->elements->count; i++) {
                ast_list_append(new_elements, $1->elements->items[i]);
            }
            ast_list_append(new_elements, (ast_node*)$2);
            ast_list_append(new_elements, (ast_node*)$3);

            /* Note: Let Bison handle memory cleanup of $1 automatically */
            /* Manual freeing during parsing can cause parser state corruption */

            $$ = make_path(new_elements);
        }
    ;

/* Full path - includes variable assignment and shortestPath wrappers */
path:
    simple_path
        {
            $$ = $1;
        }
    | IDENTIFIER '=' simple_path
        {
            $$ = make_path_with_var($1, $3->elements);
            /* Free the anonymous path structure, but keep its elements */
            free($3);
        }
    | BQIDENT '=' simple_path
        {
            /* T-0329: backtick-quoted named-path variable. */
            $$ = make_path_with_var($1, $3->elements);
            free($3);
        }
    | IDENTIFIER '=' SHORTESTPATH '(' simple_path ')'
        {
            cypher_path *sp = make_shortest_path($5->elements, PATH_TYPE_SHORTEST);
            sp->var_name = $1;
            $$ = sp;
            free($5);
        }
    | BQIDENT '=' SHORTESTPATH '(' simple_path ')'
        {
            /* T-0329: backtick-quoted variable on shortestPath. */
            cypher_path *sp = make_shortest_path($5->elements, PATH_TYPE_SHORTEST);
            sp->var_name = $1;
            $$ = sp;
            free($5);
        }
    | SHORTESTPATH '(' simple_path ')'
        {
            $$ = make_shortest_path($3->elements, PATH_TYPE_SHORTEST);
            free($3);
        }
    | IDENTIFIER '=' ALLSHORTESTPATHS '(' simple_path ')'
        {
            cypher_path *sp = make_shortest_path($5->elements, PATH_TYPE_ALL_SHORTEST);
            sp->var_name = $1;
            $$ = sp;
            free($5);
        }
    | BQIDENT '=' ALLSHORTESTPATHS '(' simple_path ')'
        {
            /* T-0329: backtick-quoted variable on allShortestPaths. */
            cypher_path *sp = make_shortest_path($5->elements, PATH_TYPE_ALL_SHORTEST);
            sp->var_name = $1;
            $$ = sp;
            free($5);
        }
    | ALLSHORTESTPATHS '(' simple_path ')'
        {
            $$ = make_shortest_path($3->elements, PATH_TYPE_ALL_SHORTEST);
            free($3);
        }
    ;

node_pattern:
    '(' variable_opt label_opt properties_opt ')'
        {
            $$ = make_node_pattern($2, $3, (ast_node*)$4);
        }
    ;

/* Relationship patterns - supports fixed and variable-length relationships
 * Each direction (outgoing ->, incoming <-, undirected -) has variants for:
 * - No type: -[var *1..5]->, -[*]->
 * - Single type: -[:TYPE*1..5]->
 * - Multiple types: -[:TYPE1|TYPE2]->
 * Variable-length syntax: *, *N, *N..M, *N.., *..M
 */
rel_pattern:
    /* Outgoing relationships: -[...]-> */
    '-' '[' variable_opt varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($3, NULL, (ast_node*)$5, false, true, (ast_node*)$4);
        }
    | '-' '[' variable_opt ':' IDENTIFIER varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, true, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' BQIDENT varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, true, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' non_reserved_kw varlen_range_opt properties_opt ']' '-' '>'
        {
            /* T-0326: keyword-named rel types (CONTAINS/STARTS/ENDS/etc.). */
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, true, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' rel_type_list varlen_range_opt properties_opt ']' '-' '>'
        {
            cypher_rel_pattern *p = make_rel_pattern_multi_type($3, $5, (ast_node*)$7, false, true);
            if (p) p->varlen = (ast_node*)$6;
            $$ = p;
        }
    /* Incoming relationships: <-[...]- */
    | '<' '-' '[' variable_opt varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($4, NULL, (ast_node*)$6, true, false, (ast_node*)$5);
        }
    | '<' '-' '[' variable_opt ':' IDENTIFIER varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, true, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' BQIDENT varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, true, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' non_reserved_kw varlen_range_opt properties_opt ']' '-'
        {
            /* T-0326: keyword-named rel types (CONTAINS/STARTS/ENDS/etc.). */
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, true, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' rel_type_list varlen_range_opt properties_opt ']' '-'
        {
            cypher_rel_pattern *p = make_rel_pattern_multi_type($4, $6, (ast_node*)$8, true, false);
            if (p) p->varlen = (ast_node*)$7;
            $$ = p;
        }
    /* Bidirectional bracketed: <-[...]-> (Match5 [27]) — equivalent to
     * undirected `-[...]-`. Per openCypher, both arrows present means "any
     * direction"; pass false/false to make_rel_pattern_varlen. */
    | '<' '-' '[' variable_opt varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($4, NULL, (ast_node*)$6, false, false, (ast_node*)$5);
        }
    | '<' '-' '[' variable_opt ':' IDENTIFIER varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, false, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' BQIDENT varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, false, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' non_reserved_kw varlen_range_opt properties_opt ']' '-' '>'
        {
            $$ = make_rel_pattern_varlen($4, $6, (ast_node*)$8, false, false, (ast_node*)$7);
            free($6);
        }
    | '<' '-' '[' variable_opt ':' rel_type_list varlen_range_opt properties_opt ']' '-' '>'
        {
            cypher_rel_pattern *p = make_rel_pattern_multi_type($4, $6, (ast_node*)$8, false, false);
            if (p) p->varlen = (ast_node*)$7;
            $$ = p;
        }
    /* Undirected relationships: -[...]- */
    | '-' '[' variable_opt varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($3, NULL, (ast_node*)$5, false, false, (ast_node*)$4);
        }
    | '-' '[' variable_opt ':' IDENTIFIER varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, false, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' BQIDENT varlen_range_opt properties_opt ']' '-'
        {
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, false, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' non_reserved_kw varlen_range_opt properties_opt ']' '-'
        {
            /* T-0326: keyword-named rel types (CONTAINS/STARTS/ENDS/etc.). */
            $$ = make_rel_pattern_varlen($3, $5, (ast_node*)$7, false, false, (ast_node*)$6);
            free($5);
        }
    | '-' '[' variable_opt ':' rel_type_list varlen_range_opt properties_opt ']' '-'
        {
            cypher_rel_pattern *p = make_rel_pattern_multi_type($3, $5, (ast_node*)$7, false, false);
            if (p) p->varlen = (ast_node*)$6;
            $$ = p;
        }
    /* Bare relationship patterns (no brackets): --, -->, <--, <--> */
    | '-' '-' '>'
        {
            $$ = make_rel_pattern_varlen(NULL, NULL, NULL, false, true, NULL);
        }
    | '<' '-' '-'
        {
            $$ = make_rel_pattern_varlen(NULL, NULL, NULL, true, false, NULL);
        }
    | '<' '-' '-' '>'
        {
            /* Bidirectional bare arrow — equivalent to `--` (any direction).
             * openCypher accepts <--> as an explicit bidirectional form. */
            $$ = make_rel_pattern_varlen(NULL, NULL, NULL, false, false, NULL);
        }
    | '-' '-'
        {
            $$ = make_rel_pattern_varlen(NULL, NULL, NULL, false, false, NULL);
        }
    ;

variable_opt:
    /* empty */     { $$ = NULL; }
    | IDENTIFIER    { $$ = $1; }
    | BQIDENT       { $$ = $1; }
    | END_P         { $$ = strdup("end"); }  /* Allow 'end' as variable name */
    ;

/* Variable-length range for relationships: *, *1..5, *2.., *..3 */
varlen_range_opt:
    /* empty - not variable length */
        { $$ = NULL; }
    | '*'
        { $$ = make_varlen_range(1, -1); }  /* unbounded: 1 to infinity */
    | '*' INTEGER
        { $$ = make_varlen_range($2, $2); }  /* exact: *3 means exactly 3 hops */
    | '*' INTEGER DOT_DOT INTEGER
        { $$ = make_varlen_range($2, $4); }  /* bounded: *1..5 */
    | '*' INTEGER DOT_DOT
        { $$ = make_varlen_range($2, -1); }  /* min bounded: *2.. */
    | '*' DOT_DOT INTEGER
        { $$ = make_varlen_range(1, $3); }   /* max bounded: *..3 */
    | '*' DOT_DOT
        { $$ = make_varlen_range(1, -1); }   /* unbounded with explicit range: *.. */
    | '*' '-' INTEGER
        {
            /* `[*-2]` (Match4 [10]) */
            free(context->error_message);
            context->error_message = strdup("SyntaxError: InvalidRelationshipPattern: a variable-length bound cannot be negative");
            context->has_error = true;
            context->error_location = @2.first_line;
            context->error_column = @2.first_column;
            $$ = NULL;
            YYERROR;
        }
    ;

label_opt:
    /* empty */         { $$ = NULL; }
    | label_list        { $$ = $1; }
    | ':' label_alt_list
        {
            /* `:A|B`: one AST_NODE_LIST item; make_node_pattern moves it to
             * label_alternatives (GQLITE-T-0125) */
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)make_list($2, @1.first_line));
        }
    ;

/* Support for multiple labels: :Label1:Label2:Label3 or :`Quoted Label` */
label_name:
    IDENTIFIER          { $$ = $1; }
    | BQIDENT           { $$ = $1; }
    | non_reserved_kw   { $$ = $1; }
    ;

label_alt_list:
    label_name '|' label_name
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)make_string_literal($1, @1.first_line));
            ast_list_append($$, (ast_node*)make_string_literal($3, @3.first_line));
            free($1); free($3);
        }
    | label_alt_list '|' label_name
        {
            ast_list_append($1, (ast_node*)make_string_literal($3, @3.first_line));
            free($3);
            $$ = $1;
        }
    ;

label_list:
    ':' IDENTIFIER
        {
            $$ = ast_list_create();
            cypher_literal *label = make_string_literal($2, @2.first_line);
            ast_list_append($$, (ast_node*)label);
            free($2);
        }
    | ':' BQIDENT
        {
            $$ = ast_list_create();
            cypher_literal *label = make_string_literal($2, @2.first_line);
            ast_list_append($$, (ast_node*)label);
            free($2);
        }
    | ':' non_reserved_kw
        {
            $$ = ast_list_create();
            cypher_literal *label = make_string_literal($2, @2.first_line);
            ast_list_append($$, (ast_node*)label);
            free($2);
        }
    | label_list ':' IDENTIFIER
        {
            $$ = $1;
            cypher_literal *label = make_string_literal($3, @3.first_line);
            ast_list_append($$, (ast_node*)label);
            free($3);
        }
    | label_list ':' non_reserved_kw
        {
            $$ = $1;
            cypher_literal *label = make_string_literal($3, @3.first_line);
            ast_list_append($$, (ast_node*)label);
            free($3);
        }
    | label_list ':' BQIDENT
        {
            $$ = $1;
            cypher_literal *label = make_string_literal($3, @3.first_line);
            ast_list_append($$, (ast_node*)label);
            free($3);
        }
    ;

rel_type_list:
    label_name '|' label_name
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)make_string_literal($1, @1.first_line));
            ast_list_append($$, (ast_node*)make_string_literal($3, @3.first_line));
            free($1); free($3);
        }
    | label_name '|' ':' label_name
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)make_string_literal($1, @1.first_line));
            ast_list_append($$, (ast_node*)make_string_literal($4, @4.first_line));
            free($1); free($4);
        }
    | rel_type_list '|' label_name
        {
            ast_list_append($1, (ast_node*)make_string_literal($3, @3.first_line));
            free($3);
            $$ = $1;
        }
    | rel_type_list '|' ':' label_name
        {
            ast_list_append($1, (ast_node*)make_string_literal($4, @4.first_line));
            free($4);
            $$ = $1;
        }
    ;

/* Expressions */
expr:
    primary_expr        { $$ = $1; }
    | '+' expr %prec UNARY_PLUS  { $$ = $2; }  /* unary plus - just return the expression */
    | '-' expr %prec UNARY_MINUS  { 
        /* Handle unary minus */
        if ($2->type == AST_NODE_LITERAL) {
            cypher_literal *lit = (cypher_literal*)$2;
            if (lit->literal_type == LITERAL_INTEGER) {
                if (lit->value.integer == INT64_MIN) {
                    /* -2^63: the scanner's pending INT64_MIN */
                    if (context && context->scanner && context->scanner->int_min_pending > 0)
                        context->scanner->int_min_pending--;
                } else {
                    lit->value.integer = -lit->value.integer;
                }
                $$ = $2;
            } else if (lit->literal_type == LITERAL_DECIMAL) {
                lit->value.decimal = -lit->value.decimal;
                $$ = $2;
            } else {
                /* Non-numeric literal: negate as 0 - lit. */
                $$ = (ast_node*)make_binary_op(BINARY_OP_SUB,
                        (ast_node*)make_integer_literal(0, @1.first_line), $2, @1.first_line);
            }
        } else {
            /* Non-literal operand (e.g. -3^2, -x, -(a+b)): build a real
             * negation as 0 - expr; previously the negation was silently
             * dropped. (Precedence2 [4]/[5].) */
            $$ = (ast_node*)make_binary_op(BINARY_OP_SUB,
                    (ast_node*)make_integer_literal(0, @1.first_line), $2, @1.first_line);
        }
    }
    | expr '+' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_ADD, $1, $3, @2.first_line); }
    | expr '-' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_SUB, $1, $3, @2.first_line); }
    | expr '*' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_MUL, $1, $3, @2.first_line); }
    | expr '/' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_DIV, $1, $3, @2.first_line); }
    | expr '%' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_MOD, $1, $3, @2.first_line); }
    | expr '^' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_POW, $1, $3, @2.first_line); }
    | expr '=' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_EQ, $1, $3, @2.first_line); }
    | expr NOT_EQ expr  { $$ = (ast_node*)make_binary_op(BINARY_OP_NEQ, $1, $3, @2.first_line); }
    /* %dprec: `(a)-->(:C)<-[s]-(b {k: 1})` in WHERE is a pattern, not
     * `... < -[s] - b {k: 1}` (Pattern1 [10]). */
    | expr '<' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_LT, $1, $3, @2.first_line); } %dprec 1
    | expr '>' expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_GT, $1, $3, @2.first_line); } %dprec 1
    | expr LT_EQ expr   { $$ = (ast_node*)make_binary_op(BINARY_OP_LTE, $1, $3, @2.first_line); }
    | expr GT_EQ expr   { $$ = (ast_node*)make_binary_op(BINARY_OP_GTE, $1, $3, @2.first_line); }
    | expr REGEX_MATCH expr { $$ = (ast_node*)make_binary_op(BINARY_OP_REGEX_MATCH, $1, $3, @2.first_line); }
    | expr AND expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_AND, $1, $3, @2.first_line); }
    | expr OR expr      { $$ = (ast_node*)make_binary_op(BINARY_OP_OR, $1, $3, @2.first_line); }
    | expr XOR expr     { $$ = (ast_node*)make_binary_op(BINARY_OP_XOR, $1, $3, @2.first_line); }
    | expr IN expr      { $$ = (ast_node*)make_binary_op(BINARY_OP_IN, $1, $3, @2.first_line); }
    | expr STARTS WITH expr %prec STARTS { $$ = (ast_node*)make_binary_op(BINARY_OP_STARTS_WITH, $1, $4, @2.first_line); }
    | expr ENDS WITH expr %prec ENDS    { $$ = (ast_node*)make_binary_op(BINARY_OP_ENDS_WITH, $1, $4, @2.first_line); }
    | expr CONTAINS expr %prec CONTAINS { $$ = (ast_node*)make_binary_op(BINARY_OP_CONTAINS, $1, $3, @2.first_line); }
    | NOT expr          { $$ = (ast_node*)make_not_expr($2, @1.first_line); }
    | expr IS NULL_P      { $$ = (ast_node*)make_null_check($1, false, @2.first_line); }
    | expr IS NOT NULL_P  { $$ = (ast_node*)make_null_check($1, true, @2.first_line); }
    | '(' expr ')'      { $$ = $2; if ($$) $$->parenthesized = true; }
    /* Pattern predicate: bare relationship pattern as boolean expression.
     * Per openCypher 9 spec, a RelationshipsPattern in boolean context
     * is an implicit existence check: (n)-[:REL]->() ≡ EXISTS((n)-[:REL]->())
     * Requires at least one relationship to distinguish from parenthesized expr.
     */
    | node_pattern rel_pattern node_pattern
        {
            /* Build a path from the pattern elements */
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)$1);
            ast_list_append(elements, (ast_node*)$2);
            ast_list_append(elements, (ast_node*)$3);
            cypher_path *path = make_path(elements);
            /* Wrap in pattern list and create EXISTS expression */
            ast_list *pattern_list = ast_list_create();
            ast_list_append(pattern_list, (ast_node*)path);
            $$ = (ast_node*)make_exists_pattern_expr(pattern_list, @1.first_line);
        } %dprec 2
    | node_pattern rel_pattern node_pattern rel_pattern node_pattern
        {
            /* Chained pattern: (a)-[r1]->(b)-[r2]->(c) */
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)$1);
            ast_list_append(elements, (ast_node*)$2);
            ast_list_append(elements, (ast_node*)$3);
            ast_list_append(elements, (ast_node*)$4);
            ast_list_append(elements, (ast_node*)$5);
            cypher_path *path = make_path(elements);
            ast_list *pattern_list = ast_list_create();
            ast_list_append(pattern_list, (ast_node*)path);
            $$ = (ast_node*)make_exists_pattern_expr(pattern_list, @1.first_line);
        } %dprec 2
    | expr '.' IDENTIFIER
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | expr '.' BQIDENT
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | expr '.' non_reserved_kw
        {
            $$ = (ast_node*)make_property($1, $3, @3.first_line);
            free($3);
        }
    | expr '[' expr ']'
        {
            $$ = (ast_node*)make_subscript($1, $3, @2.first_line);
        }
    | expr '[' expr DOT_DOT expr ']'
        {
            $$ = (ast_node*)make_slice($1, $3, $5, @2.first_line);
        }
    | expr '[' expr DOT_DOT ']'
        {
            $$ = (ast_node*)make_slice($1, $3, NULL, @2.first_line);
        }
    | expr '[' DOT_DOT expr ']'
        {
            $$ = (ast_node*)make_slice($1, NULL, $4, @2.first_line);
        }
    ;

primary_expr:
    literal_expr        { $$ = $1; }
    | identifier        { $$ = (ast_node*)$1; }
    | parameter         { $$ = (ast_node*)$1; }
    | function_call     { $$ = $1; }
    | list_predicate    { $$ = $1; }
    | reduce_expr       { $$ = $1; }
    | list_literal      { $$ = $1; } %dprec 1
    | list_comprehension { $$ = $1; } %dprec 2
    | pattern_comprehension { $$ = $1; }
    | map_literal       { $$ = $1; }
    | map_projection    { $$ = $1; }
    | case_expression   { $$ = $1; }
    | IDENTIFIER ':' IDENTIFIER
        {
            cypher_identifier *base = make_identifier($1, @1.first_line);
            $$ = (ast_node*)make_label_expr((ast_node*)base, $3, @3.first_line);
            free($1);
            free($3);
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* Conjunctive label expression `n:L1:L2` — emit
             * (n:L1) AND (n:L2). */
            cypher_identifier *b1 = make_identifier($1, @1.first_line);
            cypher_identifier *b2 = make_identifier(strdup($1), @1.first_line);
            cypher_label_expr *l1 = make_label_expr((ast_node*)b1, $3, @3.first_line);
            cypher_label_expr *l2 = make_label_expr((ast_node*)b2, $5, @5.first_line);
            $$ = (ast_node*)make_binary_op(BINARY_OP_AND,
                                            (ast_node*)l1, (ast_node*)l2,
                                            @1.first_line);
            free($1); free($3); free($5);
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* Three-label conjunction. */
            cypher_identifier *b1 = make_identifier($1, @1.first_line);
            cypher_identifier *b2 = make_identifier(strdup($1), @1.first_line);
            cypher_identifier *b3 = make_identifier(strdup($1), @1.first_line);
            cypher_label_expr *l1 = make_label_expr((ast_node*)b1, $3, @3.first_line);
            cypher_label_expr *l2 = make_label_expr((ast_node*)b2, $5, @5.first_line);
            cypher_label_expr *l3 = make_label_expr((ast_node*)b3, $7, @7.first_line);
            cypher_binary_op *and12 = make_binary_op(BINARY_OP_AND,
                                                     (ast_node*)l1, (ast_node*)l2,
                                                     @1.first_line);
            $$ = (ast_node*)make_binary_op(BINARY_OP_AND,
                                            (ast_node*)and12, (ast_node*)l3,
                                            @1.first_line);
            free($1); free($3); free($5); free($7);
        }
    | IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER ':' IDENTIFIER
        {
            /* Four-label conjunction (Graph5 [4], e.g. `a:C:A:A:C`).
             * Repeated labels are harmless — each conjunct is an
             * independent EXISTS check. */
            cypher_identifier *b1 = make_identifier($1, @1.first_line);
            cypher_identifier *b2 = make_identifier(strdup($1), @1.first_line);
            cypher_identifier *b3 = make_identifier(strdup($1), @1.first_line);
            cypher_identifier *b4 = make_identifier(strdup($1), @1.first_line);
            cypher_label_expr *l1 = make_label_expr((ast_node*)b1, $3, @3.first_line);
            cypher_label_expr *l2 = make_label_expr((ast_node*)b2, $5, @5.first_line);
            cypher_label_expr *l3 = make_label_expr((ast_node*)b3, $7, @7.first_line);
            cypher_label_expr *l4 = make_label_expr((ast_node*)b4, $9, @9.first_line);
            cypher_binary_op *and12 = make_binary_op(BINARY_OP_AND,
                                                     (ast_node*)l1, (ast_node*)l2,
                                                     @1.first_line);
            cypher_binary_op *and123 = make_binary_op(BINARY_OP_AND,
                                                      (ast_node*)and12, (ast_node*)l3,
                                                      @1.first_line);
            $$ = (ast_node*)make_binary_op(BINARY_OP_AND,
                                            (ast_node*)and123, (ast_node*)l4,
                                            @1.first_line);
            free($1); free($3); free($5); free($7); free($9);
        }
    ;

literal_expr:
    literal             { $$ = (ast_node*)$1; }
    ;

qualified_function_name:
    IDENTIFIER '.' label_name
        {
            size_t len = strlen($1) + strlen($3) + 2;
            $$ = malloc(len);
            if ($$) snprintf($$, len, "%s.%s", $1, $3);
            free($1);
            free($3);
        }
    | qualified_function_name '.' label_name
        {
            size_t len = strlen($1) + strlen($3) + 2;
            $$ = malloc(len);
            if ($$) snprintf($$, len, "%s.%s", $1, $3);
            free($1);
            free($3);
        }
    ;

function_call:
    /* Qualified function names (e.g. `date.truncate(...)`, `datetime.fromEpoch(...)`)
     * are concatenated into a single function name so the dispatch table
     * can look them up. */
    qualified_function_name '(' argument_list ')'
        {
            $$ = (ast_node*)make_function_call($1, $3, false, @1.first_line);
            free($1);
        }
    | qualified_function_name '(' ')'
        {
            ast_list *args = ast_list_create();
            $$ = (ast_node*)make_function_call($1, args, false, @1.first_line);
            free($1);
        }
    | IDENTIFIER '(' ')'
        {
            /* Check if this is EXISTS function call */
            if (strcasecmp($1, "exists") == 0) {
                /* Empty EXISTS() - invalid */
                free($1);
                cypher_yyerror(&@1, context, "EXISTS requires an argument");
                YYERROR;
            } else {
                ast_list *args = ast_list_create();
                $$ = (ast_node*)make_function_call($1, args, false, @1.first_line);
                free($1);
            }
        }
    /* Single and multiple argument function calls using argument_list */
    | IDENTIFIER '(' argument_list ')'
        {
            /* Check if this is EXISTS function call */
            if (strcasecmp($1, "exists") == 0) {
                /* EXISTS with argument list - check first arg */
                if ($3->count == 1 && $3->items[0] != NULL) {
                    ast_node *arg = $3->items[0];
                    if (arg->type == AST_NODE_PROPERTY) {
                        $$ = (ast_node*)make_exists_property_expr(arg, @1.first_line);
                        $3->items[0] = NULL;  /* Transfer ownership */
                        ast_list_free($3);
                    } else {
                        $$ = (ast_node*)make_exists_pattern_expr($3, @1.first_line);
                    }
                } else {
                    cypher_yyerror(&@1, context, "EXISTS requires exactly one argument");
                    ast_list_free($3);
                    free($1);
                    YYERROR;
                }
                free($1);
            } else {
                $$ = (ast_node*)make_function_call($1, $3, false, @1.first_line);
                free($1);
            }
        }
    | IDENTIFIER '(' DISTINCT expr ')'
        {
            ast_list *args = ast_list_create();
            ast_list_append(args, $4);
            $$ = (ast_node*)make_function_call($1, args, true, @1.first_line);
            free($1);
        }
    | IDENTIFIER '(' '*' ')'
        {
            ast_list *args = ast_list_create();
            /* For count(*), we'll use a special NULL argument to indicate * */
            ast_list_append(args, NULL);
            $$ = (ast_node*)make_function_call($1, args, false, @1.first_line);
            free($1);
        }
    | EXISTS '(' pattern_list ')'
        {
            /* EXISTS((pattern)) - check for relationship/path existence */
            $$ = (ast_node*)make_exists_pattern_expr($3, @1.first_line);
        }
    | EXISTS '{' pattern_list '}'
        {
            /* Existential subquery brace form: EXISTS { (n)-->() }
             * (ExistentialSubquery1 [1]/[3]). Reuses the pattern-existence
             * transform; correlated outer variables resolve via the
             * EXISTS_TYPE_PATTERN emitter's outer-alias lookup. */
            cypher_exists_expr *ee = make_exists_pattern_expr($3, @1.first_line);
            if (ee) ee->is_subquery = true;
            $$ = (ast_node*)ee;
        }
    | EXISTS '{' single_query '}'
        {
            /* GQLITE-T-0139: full existential subquery
             * EXISTS { MATCH (n)-->(m) [WITH ... WHERE ...] RETURN true }
             * (CIP2015-05-13-EXISTS level 3; ExistentialSubquery2/3). */
            $$ = (ast_node*)make_exists_query_expr($3, @1.first_line);
        }
    | EXISTS '{' pattern_list WHERE expr '}'
        {
            /* Existential subquery with inner WHERE:
             * EXISTS { (n)-->(m) WHERE n.prop = m.prop }
             * (ExistentialSubquery1 [2]/[4]). The inner predicate is stored
             * on where_clause and folded into the subquery by the transform,
             * which registers the inner pattern variables first. */
            cypher_exists_expr *ee = make_exists_pattern_expr($3, @1.first_line);
            if (ee) { ee->where_clause = $5; ee->is_subquery = true; }
            $$ = (ast_node*)ee;
        }
    | EXISTS '(' IDENTIFIER '.' IDENTIFIER ')'
        {
            /* EXISTS(n.property) - unambiguous property existence check */
            ast_node *var = (ast_node*)make_identifier($3, @3.first_line);
            ast_node *prop = (ast_node*)make_property(var, $5, @1.first_line);
            $$ = (ast_node*)make_exists_property_expr(prop, @1.first_line);
            free($3);
            free($5);
        }
    /* Allow keyword-named functions: contains(), startsWith(), endsWith() */
    | CONTAINS '(' argument_list ')'
        {
            $$ = (ast_node*)make_function_call(strdup("contains"), $3, false, @1.first_line);
        }
    | STARTS '(' argument_list ')'
        {
            /* startsWith function uses STARTS keyword */
            $$ = (ast_node*)make_function_call(strdup("startsWith"), $3, false, @1.first_line);
        }
    | ENDS '(' argument_list ')'
        {
            /* endsWith function uses ENDS keyword */
            $$ = (ast_node*)make_function_call(strdup("endsWith"), $3, false, @1.first_line);
        }
    ;

/* List predicates: all(), any(), none(), single() */
list_predicate:
    ALL '(' IDENTIFIER IN expr WHERE expr ')'
        {
            $$ = (ast_node*)make_list_predicate(LIST_PRED_ALL, $3, $5, $7, @1.first_line);
            free($3);
        }
    | ANY '(' IDENTIFIER IN expr WHERE expr ')'
        {
            $$ = (ast_node*)make_list_predicate(LIST_PRED_ANY, $3, $5, $7, @1.first_line);
            free($3);
        }
    | NONE '(' IDENTIFIER IN expr WHERE expr ')'
        {
            $$ = (ast_node*)make_list_predicate(LIST_PRED_NONE, $3, $5, $7, @1.first_line);
            free($3);
        }
    | SINGLE '(' IDENTIFIER IN expr WHERE expr ')'
        {
            $$ = (ast_node*)make_list_predicate(LIST_PRED_SINGLE, $3, $5, $7, @1.first_line);
            free($3);
        }
    ;

/* Reduce expression: reduce(acc = initial, x IN list | expression) */
reduce_expr:
    REDUCE '(' IDENTIFIER '=' expr ',' IDENTIFIER IN expr '|' expr ')'
        {
            /* reduce(acc = initial, x IN list | expression) */
            $$ = (ast_node*)make_reduce_expr($3, $5, $7, $9, $11, @1.first_line);
            free($3);
            free($7);
        }
    ;

/* Argument list for function calls: expr, expr, ... */
argument_list:
    expr
        {
            $$ = ast_list_create();
            ast_list_append($$, $1);
        }
    | argument_list ',' expr
        {
            ast_list_append($1, $3);
            $$ = $1;
        }
    ;

/* List literal: [item1, item2, ...] */
list_literal:
    '[' ']'
        {
            $$ = (ast_node*)make_list(ast_list_create(), @1.first_line);
        }
    | '[' return_item_list ']'
        {
            /* Reuse return_item_list for comma-separated expressions */
            /* But we need to extract the expressions from return_items */
            ast_list *exprs = ast_list_create();
            for (int i = 0; i < $2->count; i++) {
                cypher_return_item *item = (cypher_return_item*)$2->items[i];
                ast_list_append(exprs, item->expr);
                item->expr = NULL;  /* Prevent double-free */
            }
            ast_list_free($2);
            $$ = (ast_node*)make_list(exprs, @1.first_line);
        }
    ;

/* List comprehension: [x IN list], [x IN list WHERE cond], [x IN list | expr], [x IN list WHERE cond | expr] */
list_comprehension:
    '[' IDENTIFIER IN expr ']'
        {
            $$ = (ast_node*)make_list_comprehension($2, $4, NULL, NULL, @1.first_line);
            free($2);
        }
    | '[' IDENTIFIER IN expr WHERE expr ']'
        {
            $$ = (ast_node*)make_list_comprehension($2, $4, $6, NULL, @1.first_line);
            free($2);
        }
    | '[' IDENTIFIER IN expr '|' expr ']'
        {
            $$ = (ast_node*)make_list_comprehension($2, $4, NULL, $6, @1.first_line);
            free($2);
        }
    | '[' IDENTIFIER IN expr WHERE expr '|' expr ']'
        {
            $$ = (ast_node*)make_list_comprehension($2, $4, $6, $8, @1.first_line);
            free($2);
        }
    ;

/* Pattern comprehension: [(n)-[r]->(m) | expr]
 *
 * Standard OpenCypher syntax. GLR parser handles the ambiguity with list literals
 * by exploring both parse paths - the wrong one fails and is discarded.
 *
 * Examples:
 *   [(a)-[r]->(b) | b.name]
 *   [(a:Person)-[:KNOWS]->(b) WHERE b.age > 21 | b.name]
 */
pattern_comprehension:
    '[' '(' variable_opt label_opt properties_opt ')' rel_pattern node_pattern '|' expr ']'
        {
            cypher_node_pattern *first = make_node_pattern($3, $4, (ast_node*)$5);
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)first);
            ast_list_append(elements, (ast_node*)$7);
            ast_list_append(elements, (ast_node*)$8);
            cypher_path *path = make_path(elements);

            ast_list *pattern = ast_list_create();
            ast_list_append(pattern, (ast_node*)path);
            $$ = (ast_node*)make_pattern_comprehension(pattern, NULL, $10, @1.first_line);
        }
    | '[' '(' variable_opt label_opt properties_opt ')' rel_pattern node_pattern WHERE expr '|' expr ']'
        {
            cypher_node_pattern *first = make_node_pattern($3, $4, (ast_node*)$5);
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)first);
            ast_list_append(elements, (ast_node*)$7);
            ast_list_append(elements, (ast_node*)$8);
            cypher_path *path = make_path(elements);

            ast_list *pattern = ast_list_create();
            ast_list_append(pattern, (ast_node*)path);
            $$ = (ast_node*)make_pattern_comprehension(pattern, $10, $12, @1.first_line);
        }
    /* T-0332: path-assignment form `[p = (...)-->(...) | expr]` */
    | '[' IDENTIFIER '=' '(' variable_opt label_opt properties_opt ')' rel_pattern node_pattern '|' expr ']'
        {
            cypher_node_pattern *first = make_node_pattern($5, $6, (ast_node*)$7);
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)first);
            ast_list_append(elements, (ast_node*)$9);
            ast_list_append(elements, (ast_node*)$10);
            cypher_path *path = make_path(elements);

            ast_list *pattern = ast_list_create();
            ast_list_append(pattern, (ast_node*)path);
            cypher_pattern_comprehension *pc = make_pattern_comprehension(pattern, NULL, $12, @1.first_line);
            pc->path_var = strdup($2);
            $$ = (ast_node*)pc;
        }
    | '[' IDENTIFIER '=' '(' variable_opt label_opt properties_opt ')' rel_pattern node_pattern WHERE expr '|' expr ']'
        {
            cypher_node_pattern *first = make_node_pattern($5, $6, (ast_node*)$7);
            ast_list *elements = ast_list_create();
            ast_list_append(elements, (ast_node*)first);
            ast_list_append(elements, (ast_node*)$9);
            ast_list_append(elements, (ast_node*)$10);
            cypher_path *path = make_path(elements);

            ast_list *pattern = ast_list_create();
            ast_list_append(pattern, (ast_node*)path);
            cypher_pattern_comprehension *pc = make_pattern_comprehension(pattern, $12, $14, @1.first_line);
            pc->path_var = strdup($2);
            $$ = (ast_node*)pc;
        }
    ;

/* Map literal: {key: value, ...} */
map_literal:
    '{' '}'
        {
            $$ = (ast_node*)make_map(ast_list_create(), @1.first_line);
        }
    | '{' map_pair_list '}'
        {
            $$ = (ast_node*)make_map($2, @1.first_line);
        }
    | '{' map_pair_list ',' '}'
        {
            /* A single trailing comma is accepted for template compatibility. */
            $$ = (ast_node*)make_map($2, @1.first_line);
        }
    ;

/* Map projection: n{.prop1, .prop2} or n{alias: .prop, ...} */
map_projection:
    IDENTIFIER '{' map_projection_list '}'
        {
            cypher_identifier *base = make_identifier($1, @1.first_line);
            $$ = (ast_node*)make_map_projection((ast_node*)base, $3, @1.first_line);
            free($1);
        }
    ;

map_projection_list:
    map_projection_item
        {
            $$ = ast_list_create();
            ast_list_append($$, $1);
        }
    | map_projection_list ',' map_projection_item
        {
            ast_list_append($1, $3);
            $$ = $1;
        }
    ;

map_projection_item:
    '.' IDENTIFIER
        {
            /* Shorthand: .prop -> key=prop, property=prop, expr=NULL */
            $$ = (ast_node*)make_map_projection_item($2, $2, NULL, @1.first_line);
            free($2);
        }
    | '.' '*'
        {
            /* All properties: .* -> key=NULL, property="*", expr=NULL */
            $$ = (ast_node*)make_map_projection_item(NULL, strdup("*"), NULL, @1.first_line);
        }
    | IDENTIFIER ':' '.' IDENTIFIER
        {
            /* Aliased property: alias: .prop */
            $$ = (ast_node*)make_map_projection_item($1, $4, NULL, @1.first_line);
            free($1);
            free($4);
        }
    | IDENTIFIER ':' expr
        {
            /* Computed value: alias: expr */
            $$ = (ast_node*)make_map_projection_item($1, NULL, $3, @1.first_line);
            free($1);
        }
    | IDENTIFIER
        {
            /* Variable selector: `m {x}` is `m {x: x}` (GQLITE-T-0136) */
            $$ = (ast_node*)make_map_projection_item($1, NULL,
                     (ast_node*)make_identifier($1, @1.first_line), @1.first_line);
            free($1);
        }
    ;

/* CASE expression - two forms:
 *   Searched: CASE WHEN cond THEN val [...] [ELSE val] END
 *   Simple:   CASE expr WHEN val THEN result [...] [ELSE val] END
 */
case_expression:
    /* Searched CASE: CASE WHEN ... END */
    CASE when_clause_list END_P
        {
            $$ = (ast_node*)make_case_expr(NULL, $2, NULL, @1.first_line);
        }
    | CASE when_clause_list ELSE expr END_P
        {
            $$ = (ast_node*)make_case_expr(NULL, $2, $4, @1.first_line);
        }
    /* Simple CASE: CASE expr WHEN ... END */
    | CASE expr when_clause_list END_P
        {
            $$ = (ast_node*)make_case_expr($2, $3, NULL, @1.first_line);
        }
    | CASE expr when_clause_list ELSE expr END_P
        {
            $$ = (ast_node*)make_case_expr($2, $3, $5, @1.first_line);
        }
    ;

when_clause_list:
    when_clause
        {
            $$ = ast_list_create();
            ast_list_append($$, $1);
        }
    | when_clause_list when_clause
        {
            ast_list_append($1, $2);
            $$ = $1;
        }
    ;

when_clause:
    WHEN expr THEN expr
        {
            $$ = (ast_node*)make_when_clause($2, $4, @1.first_line);
        }
    ;

literal:
    INTEGER
        {
            $$ = make_integer_literal($1, @1.first_line);
        }
    | DECIMAL
        {
            $$ = make_decimal_literal($1, @1.first_line);
        }
    | STRING
        {
            $$ = make_string_literal($1, @1.first_line);
            free($1);
        }
    | TRUE_P
        {
            $$ = make_boolean_literal(true, @1.first_line);
        }
    | FALSE_P
        {
            $$ = make_boolean_literal(false, @1.first_line);
        }
    | NULL_P
        {
            $$ = make_null_literal(@1.first_line);
        }
    ;

identifier:
    IDENTIFIER
        {
            $$ = make_identifier($1, @1.first_line);
            free($1);
        }
    | BQIDENT
        {
            $$ = make_identifier($1, @1.first_line);
            free($1);
        }
    | END_P
        {
            /* Allow 'end' as an identifier - it's only reserved in CASE...END context */
            $$ = make_identifier(strdup("end"), @1.first_line);
        }
    ;

/* Keywords that may serve as identifiers/labels/property-keys outside their
 * reserved contexts. Returns the string form (caller frees). */
non_reserved_kw:
    /* A keyword used as a name (label, relationship type, property, map
     * key) keeps its spelling as written (Unwind1 [6]: `[:IN]`; Map1 [5]). */
      SINGLE        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "SINGLE"); }
    | ANY           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ANY"); }
    | NONE          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "NONE"); }
    | ALL           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ALL"); }
    | EXISTS        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "EXISTS"); }
    | CONTAINS      { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "CONTAINS"); }
    | STARTS        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "STARTS"); }
    | ENDS          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ENDS"); }
    | REDUCE        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "REDUCE"); }
    | END_P         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "END"); }
    | ON            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ON"); }
    | PATTERN       { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "PATTERN"); }
    | CSV           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "CSV"); }
    | LOAD          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "LOAD"); }
    | YIELD         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "YIELD"); }
    | IN            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "IN"); }
    | IS            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "IS"); }
    | AS            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "AS"); }
    | OR            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "OR"); }
    | AND           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "AND"); }
    | XOR           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "XOR"); }
    | NOT           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "NOT"); }
    | ORDER         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ORDER"); }
    | BY            { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "BY"); }
    | NULL_P        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "NULL"); }
    | CASE          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "CASE"); }
    | WHEN          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "WHEN"); }
    | THEN          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "THEN"); }
    | ELSE          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "ELSE"); }
    | MATCH         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "MATCH"); }
    | RETURN        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "RETURN"); }
    | CREATE        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "CREATE"); }
    | WHERE         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "WHERE"); }
    | WITH          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "WITH"); }
    | SET           { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "SET"); }
    | DELETE        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "DELETE"); }
    | REMOVE        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "REMOVE"); }
    | MERGE         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "MERGE"); }
    | UNWIND        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "UNWIND"); }
    | DETACH        { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "DETACH"); }
    | FOREACH       { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "FOREACH"); }
    | CALL          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "CALL"); }
    | OPTIONAL      { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "OPTIONAL"); }
    | DISTINCT      { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "DISTINCT"); }
    | SKIP          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "SKIP"); }
    | LIMIT         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "LIMIT"); }
    | UNION         { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "UNION"); }
    | FROM          { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "FROM"); }
    | HEADERS       { $$ = keyword_text_at(context, @1.first_line, @1.first_column, "HEADERS"); }
    ;

parameter:
    PARAMETER
        {
            $$ = make_parameter($1, @1.first_line);
            free($1);
        }
    ;

/* Property map support */
properties_opt:
    /* empty */         { $$ = NULL; }
    | '{' '}'           {
            /* Empty `{}` produces an empty-map node so downstream
             * validation distinguishes "no properties block written"
             * (NULL) from "explicit empty map" — the latter counts as
             * a property predicate for re-bind detection. */
            $$ = make_map(ast_list_create(), @1.first_line);
        }
    | '{' map_pair_list '}'
        {
            $$ = make_map($2, @1.first_line);
        }
    ;

map_pair_list:
    map_pair
        {
            $$ = ast_list_create();
            ast_list_append($$, (ast_node*)$1);
        }
    | map_pair_list ',' map_pair
        {
            ast_list_append($1, (ast_node*)$3);
            $$ = $1;
        }
    ;

map_pair:
    IDENTIFIER ':' expr
        {
            $$ = make_map_pair($1, $3, @1.first_line);
        }
    | BQIDENT ':' expr
        {
            $$ = make_map_pair($1, $3, @1.first_line);
        }
    | STRING ':' expr
        {
            $$ = make_map_pair($1, $3, @1.first_line);
        }
    | non_reserved_kw ':' expr
        {
            $$ = make_map_pair($1, $3, @1.first_line);
        }
    | ASC ':' expr
        {
            $$ = make_map_pair("asc", $3, @1.first_line);
        }
    | TRUE_P ':' expr
        {
            /* `{true: true}`: a keyword as a map key keeps its spelling (Boolean4 [4]). */
            char *k = keyword_text_at(context, @1.first_line, @1.first_column, "true");
            $$ = make_map_pair(k, $3, @1.first_line);
            free(k);
        }
    | FALSE_P ':' expr
        {
            char *k = keyword_text_at(context, @1.first_line, @1.first_column, "false");
            $$ = make_map_pair(k, $3, @1.first_line);
            free(k);
        }
    | DESC ':' expr
        {
            $$ = make_map_pair("desc", $3, @1.first_line);
        }
    ;

%%

/* Error handling function */
void cypher_yyerror(CYPHER_YYLTYPE *yylloc, cypher_parser_context *context, const char *msg)
{
    if (!context || !msg) {
        return;
    }

    /* If the scanner already raised a specific error (e.g. IntegerOverflow),
     * keep its message — Bison's generic 'syntax error, unexpected end of
     * file' would otherwise mask it. */
    if (context->has_error && context->error_message) {
        return;
    }

    context->has_error = true;
    context->error_location = yylloc ? yylloc->first_line : -1;
    context->error_column = yylloc ? yylloc->first_column : -1;

    /* Create error message with line number - Bison's detailed error mode
     * provides good context about what was expected */
    char error_buffer[512];
    /* Bison's own error is the openCypher SyntaxError UnexpectedSyntax; two
     * tokens say more: a parameter where a pattern takes only a map literal
     * (`MATCH (n $p)`, Match1 [6]), and a range without `*` in a
     * relationship pattern (`[:T 1..2]`, Match4 [9]). */
    const char *cls = "";
    if (strncmp(msg, "syntax error", 12) == 0) {
        if (strstr(msg, "unexpected PARAMETER, expecting ')'") || strstr(msg, "unexpected PARAMETER, expecting ']'"))
            cls = "SyntaxError: InvalidParameterUse: ";
        else if (strstr(msg, "unexpected DOT_DOT, expecting ']'"))
            cls = "SyntaxError: InvalidRelationshipPattern: ";
        else
            cls = "SyntaxError: UnexpectedSyntax: ";
    }
    if (yylloc && yylloc->first_line > 0) {
        if (yylloc->first_column > 0) {
            snprintf(error_buffer, sizeof(error_buffer),
                     "%sLine %d, Col %d: %s", cls, yylloc->first_line, yylloc->first_column, msg);
        } else {
            snprintf(error_buffer, sizeof(error_buffer),
                     "%sLine %d: %s", cls, yylloc->first_line, msg);
        }
    } else {
        snprintf(error_buffer, sizeof(error_buffer), "%s%s", cls, msg);
    }

    free(context->error_message);
    context->error_message = strdup(error_buffer);
}

/* cypher_yylex function is implemented in cypher_parser.c */
