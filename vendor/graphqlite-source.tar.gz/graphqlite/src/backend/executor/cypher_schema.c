/*
 * Cypher Schema Manager
 * Implements proven EAV design from GraphQLite archive
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <stdint.h>

#include "executor/cypher_schema.h"
#include "parser/cypher_debug.h"

/* Hash function - djb2 algorithm */
static unsigned long hash_string(const char *str) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

/* DDL Constants - Table Creation SQL */

const char* CYPHER_SCHEMA_DDL_NODES = 
    "CREATE TABLE IF NOT EXISTS nodes ("
    "  id INTEGER PRIMARY KEY AUTOINCREMENT"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGES = 
    "CREATE TABLE IF NOT EXISTS edges ("
    "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  source_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  target_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  type TEXT NOT NULL"
    ")";

const char* CYPHER_SCHEMA_DDL_PROPERTY_KEYS = 
    "CREATE TABLE IF NOT EXISTS property_keys ("
    "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  key TEXT UNIQUE NOT NULL"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_LABELS = 
    "CREATE TABLE IF NOT EXISTS node_labels ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  label TEXT NOT NULL,"
    "  PRIMARY KEY (node_id, label)"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_PROPS_INT = 
    "CREATE TABLE IF NOT EXISTS node_props_int ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value INTEGER NOT NULL,"
    "  PRIMARY KEY (node_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_PROPS_TEXT = 
    "CREATE TABLE IF NOT EXISTS node_props_text ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value TEXT NOT NULL,"
    "  PRIMARY KEY (node_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_PROPS_REAL = 
    "CREATE TABLE IF NOT EXISTS node_props_real ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value REAL NOT NULL,"
    "  PRIMARY KEY (node_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_PROPS_BOOL = 
    "CREATE TABLE IF NOT EXISTS node_props_bool ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value INTEGER NOT NULL CHECK (value IN (0, 1)),"
    "  PRIMARY KEY (node_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGE_PROPS_INT = 
    "CREATE TABLE IF NOT EXISTS edge_props_int ("
    "  edge_id INTEGER NOT NULL REFERENCES edges(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value INTEGER NOT NULL,"
    "  PRIMARY KEY (edge_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGE_PROPS_TEXT = 
    "CREATE TABLE IF NOT EXISTS edge_props_text ("
    "  edge_id INTEGER NOT NULL REFERENCES edges(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value TEXT NOT NULL,"
    "  PRIMARY KEY (edge_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGE_PROPS_REAL = 
    "CREATE TABLE IF NOT EXISTS edge_props_real ("
    "  edge_id INTEGER NOT NULL REFERENCES edges(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value REAL NOT NULL,"
    "  PRIMARY KEY (edge_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGE_PROPS_BOOL =
    "CREATE TABLE IF NOT EXISTS edge_props_bool ("
    "  edge_id INTEGER NOT NULL REFERENCES edges(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value INTEGER NOT NULL CHECK (value IN (0, 1)),"
    "  PRIMARY KEY (edge_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_NODE_PROPS_JSON =
    "CREATE TABLE IF NOT EXISTS node_props_json ("
    "  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value TEXT NOT NULL CHECK (json_valid(value)),"
    "  PRIMARY KEY (node_id, key_id)"
    ")";

const char* CYPHER_SCHEMA_DDL_EDGE_PROPS_JSON =
    "CREATE TABLE IF NOT EXISTS edge_props_json ("
    "  edge_id INTEGER NOT NULL REFERENCES edges(id) ON DELETE CASCADE,"
    "  key_id INTEGER NOT NULL REFERENCES property_keys(id),"
    "  value TEXT NOT NULL CHECK (json_valid(value)),"
    "  PRIMARY KEY (edge_id, key_id)"
    ")";

/* Index Creation SQL */

const char* CYPHER_SCHEMA_INDEX_EDGES_SOURCE = 
    "CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id, type)";

const char* CYPHER_SCHEMA_INDEX_EDGES_TARGET =
    "CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id, type)";

const char* CYPHER_SCHEMA_INDEX_EDGES_TYPE =
    "CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(type)";

const char* CYPHER_SCHEMA_INDEX_NODE_LABELS = 
    "CREATE INDEX IF NOT EXISTS idx_node_labels_label ON node_labels(label, node_id)";

const char* CYPHER_SCHEMA_INDEX_PROPERTY_KEYS = 
    "CREATE INDEX IF NOT EXISTS idx_property_keys_key ON property_keys(key)";

const char* CYPHER_SCHEMA_INDEX_NODE_PROPS_INT = 
    "CREATE INDEX IF NOT EXISTS idx_node_props_int_key_value ON node_props_int(key_id, value, node_id)";

const char* CYPHER_SCHEMA_INDEX_NODE_PROPS_TEXT = 
    "CREATE INDEX IF NOT EXISTS idx_node_props_text_key_value ON node_props_text(key_id, value, node_id)";

const char* CYPHER_SCHEMA_INDEX_NODE_PROPS_REAL = 
    "CREATE INDEX IF NOT EXISTS idx_node_props_real_key_value ON node_props_real(key_id, value, node_id)";

const char* CYPHER_SCHEMA_INDEX_NODE_PROPS_BOOL = 
    "CREATE INDEX IF NOT EXISTS idx_node_props_bool_key_value ON node_props_bool(key_id, value, node_id)";

const char* CYPHER_SCHEMA_INDEX_EDGE_PROPS_INT = 
    "CREATE INDEX IF NOT EXISTS idx_edge_props_int_key_value ON edge_props_int(key_id, value, edge_id)";

const char* CYPHER_SCHEMA_INDEX_EDGE_PROPS_TEXT = 
    "CREATE INDEX IF NOT EXISTS idx_edge_props_text_key_value ON edge_props_text(key_id, value, edge_id)";

const char* CYPHER_SCHEMA_INDEX_EDGE_PROPS_REAL = 
    "CREATE INDEX IF NOT EXISTS idx_edge_props_real_key_value ON edge_props_real(key_id, value, edge_id)";

const char* CYPHER_SCHEMA_INDEX_EDGE_PROPS_BOOL =
    "CREATE INDEX IF NOT EXISTS idx_edge_props_bool_key_value ON edge_props_bool(key_id, value, edge_id)";

const char* CYPHER_SCHEMA_INDEX_NODE_PROPS_JSON =
    "CREATE INDEX IF NOT EXISTS idx_node_props_json_key_value ON node_props_json(key_id, node_id)";

const char* CYPHER_SCHEMA_INDEX_EDGE_PROPS_JSON =
    "CREATE INDEX IF NOT EXISTS idx_edge_props_json_key_value ON edge_props_json(key_id, edge_id)";

/* Property key cache implementation */

property_key_cache* create_property_key_cache(sqlite3 *db, int slot_count)
{
    UNUSED_PARAMETER(db);
    
    property_key_cache *cache = calloc(1, sizeof(property_key_cache));
    if (!cache) {
        return NULL;
    }
    
    cache->slot_count = slot_count;
    cache->slots = calloc(slot_count, sizeof(property_key_entry*));
    if (!cache->slots) {
        free(cache);
        return NULL;
    }
    
    /* Initialize statements to NULL - will be prepared when schema is initialized */
    cache->lookup_stmt = NULL;
    cache->insert_stmt = NULL;
    
    CYPHER_DEBUG("Created property key cache with %d slots", slot_count);
    
    return cache;
}

/* Prepare cache statements after schema initialization */
/* Note: Statements are now prepared locally in each function to avoid
 * keeping prepared statements open, which prevents sqlite3_close() from
 * succeeding when the connection is closed. */
int prepare_property_key_cache_statements(property_key_cache *cache, sqlite3 *db)
{
    UNUSED_PARAMETER(cache);
    UNUSED_PARAMETER(db);
    /* No-op: statements are now prepared on-demand and finalized immediately */
    return 0;
}

void free_property_key_cache(property_key_cache *cache)
{
    if (!cache) {
        return;
    }
    
    /* Free all cached entries - for now just free individual entries */
    /* TODO: Implement proper linked list structure */
    for (int i = 0; i < cache->slot_count; i++) {
        property_key_entry *entry = cache->slots[i];
        while (entry) {
            property_key_entry *next = entry->next;
            free(entry->key_string);
            free(entry);
            entry = next;
        }
    }
    
    if (cache->lookup_stmt) {
        sqlite3_finalize(cache->lookup_stmt);
    }
    if (cache->insert_stmt) {
        sqlite3_finalize(cache->insert_stmt);
    }
    free(cache->slots);
    free(cache);
    
    CYPHER_DEBUG("Freed property key cache");
}

/* #134: drop every cached key. Called when a query rolls back its own
 * writes, so no entry keeps an id that the rollback gave back. */
void cypher_schema_clear_property_key_cache(cypher_schema_manager *manager)
{
    if (!manager || !manager->key_cache) return;
    property_key_cache *cache = manager->key_cache;
    for (int i = 0; i < cache->slot_count; i++) {
        property_key_entry *entry = cache->slots[i];
        while (entry) {
            property_key_entry *next = entry->next;
            free(entry->key_string);
            free(entry);
            entry = next;
        }
        cache->slots[i] = NULL;
    }
    cache->total_entries = 0;
}

/* Schema manager implementation */

cypher_schema_manager* cypher_schema_create_manager(sqlite3 *db)
{
    cypher_schema_manager *manager = calloc(1, sizeof(cypher_schema_manager));
    if (!manager) {
        return NULL;
    }
    
    manager->db = db;
    manager->schema_initialized = false;
    
    /* Create property key cache with 1024 slots (proven size) */
    manager->key_cache = create_property_key_cache(db, 1024);
    if (!manager->key_cache) {
        free(manager);
        return NULL;
    }
    
    CYPHER_DEBUG("Created schema manager %p", (void*)manager);
    
    return manager;
}

/* ---- Perf review F9: prepared-statement helpers --------------------------- */

static const char *const gql_node_prop_tables[5] = {
    "node_props_int", "node_props_text", "node_props_real", "node_props_bool", "node_props_json"
};
static const char *const gql_edge_prop_tables[5] = {
    "edge_props_int", "edge_props_text", "edge_props_real", "edge_props_bool", "edge_props_json"
};

static int prop_table_index(property_type type)
{
    switch (type) {
        case PROP_TYPE_INTEGER: return 0;
        case PROP_TYPE_TEXT:    return 1;
        case PROP_TYPE_REAL:    return 2;
        case PROP_TYPE_BOOLEAN: return 3;
        case PROP_TYPE_JSON:    return 4;
        default: return -1;
    }
}

/* Return the statement in *slot, preparing it on first use and resetting
 * it (with bindings cleared) on later uses. NULL on prepare failure. */
static sqlite3_stmt *sm_stmt(cypher_schema_manager *m, sqlite3_stmt **slot, const char *sql)
{
    if (!*slot) {
        if (sqlite3_prepare_v2(m->db, sql, -1, slot, NULL) != SQLITE_OK) {
            CYPHER_DEBUG("Failed to prepare '%s': %s", sql, sqlite3_errmsg(m->db));
            *slot = NULL;
            return NULL;
        }
        return *slot;
    }
    sqlite3_reset(*slot);
    sqlite3_clear_bindings(*slot);
    return *slot;
}

/* Step a write statement to completion and reset it so it holds no cursor. */
static int sm_step_done(sqlite3_stmt *stmt)
{
    int rc = sqlite3_step(stmt);
    sqlite3_reset(stmt);
    return rc;
}

static void bind_prop_value(sqlite3_stmt *stmt, int idx, property_type type, const void *value)
{
    switch (type) {
        case PROP_TYPE_INTEGER: sqlite3_bind_int64(stmt, idx, *(const int64_t*)value); break;
        case PROP_TYPE_TEXT:    sqlite3_bind_text(stmt, idx, (const char*)value, -1, SQLITE_TRANSIENT); break;
        case PROP_TYPE_REAL:    sqlite3_bind_double(stmt, idx, *(const double*)value); break;
        case PROP_TYPE_BOOLEAN: sqlite3_bind_int(stmt, idx, *(const int*)value ? 1 : 0); break;
        case PROP_TYPE_JSON:    sqlite3_bind_text(stmt, idx, (const char*)value, -1, SQLITE_TRANSIENT); break;
        default: break;
    }
}

void cypher_schema_release_statements(cypher_schema_manager *manager)
{
    if (!manager) return;
    sqlite3_stmt **singles[] = { &manager->ps_insert_node, &manager->ps_add_label, &manager->ps_create_edge,
                                 &manager->ps_key_lookup, &manager->ps_key_insert };
    for (size_t i = 0; i < sizeof(singles) / sizeof(singles[0]); i++) {
        if (*singles[i]) { sqlite3_finalize(*singles[i]); *singles[i] = NULL; }
    }
    for (int i = 0; i < 5; i++) {
        if (manager->ps_node_prop_ins[i]) { sqlite3_finalize(manager->ps_node_prop_ins[i]); manager->ps_node_prop_ins[i] = NULL; }
        if (manager->ps_node_prop_del[i]) { sqlite3_finalize(manager->ps_node_prop_del[i]); manager->ps_node_prop_del[i] = NULL; }
        if (manager->ps_edge_prop_ins[i]) { sqlite3_finalize(manager->ps_edge_prop_ins[i]); manager->ps_edge_prop_ins[i] = NULL; }
    }
}

void cypher_schema_free_manager(cypher_schema_manager *manager)
{
    if (!manager) {
        return;
    }
    
    CYPHER_DEBUG("Freeing schema manager %p", (void*)manager);
    
    cypher_schema_release_statements(manager);
    free_property_key_cache(manager->key_cache);
    free(manager);
}

/* Execute DDL statement with error handling */
static int execute_ddl(sqlite3 *db, const char *sql, const char *description)
{
    char *error_message;
    int rc = sqlite3_exec(db, sql, NULL, NULL, &error_message);
    
    if (rc != SQLITE_OK) {
        CYPHER_DEBUG("Failed to execute %s: %s", description, error_message);
        sqlite3_free(error_message);
        return -1;
    }
    
    CYPHER_DEBUG("Successfully executed %s", description);
    return 0;
}

int cypher_schema_create_tables(cypher_schema_manager *manager)
{
    if (!manager || !manager->db) {
        return -1;
    }
    
    CYPHER_DEBUG("Creating database tables");
    
    /* Create core tables */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODES, "nodes table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGES, "edges table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_PROPERTY_KEYS, "property_keys table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_LABELS, "node_labels table") < 0) return -1;
    
    /* Create node property tables */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_PROPS_INT, "node_props_int table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_PROPS_TEXT, "node_props_text table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_PROPS_REAL, "node_props_real table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_PROPS_BOOL, "node_props_bool table") < 0) return -1;
    
    /* Create edge property tables */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGE_PROPS_INT, "edge_props_int table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGE_PROPS_TEXT, "edge_props_text table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGE_PROPS_REAL, "edge_props_real table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGE_PROPS_BOOL, "edge_props_bool table") < 0) return -1;

    /* Create JSON property tables */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_NODE_PROPS_JSON, "node_props_json table") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_DDL_EDGE_PROPS_JSON, "edge_props_json table") < 0) return -1;

    return 0;
}

int cypher_schema_create_indexes(cypher_schema_manager *manager)
{
    if (!manager || !manager->db) {
        return -1;
    }
    
    CYPHER_DEBUG("Creating database indexes");
    
    /* Create edge indexes */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGES_SOURCE, "edges source index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGES_TARGET, "edges target index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGES_TYPE, "edges type index") < 0) return -1;
    
    /* Create label and property key indexes */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_LABELS, "node labels index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_PROPERTY_KEYS, "property keys index") < 0) return -1;
    
    /* Create property-first indexes */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_PROPS_INT, "node props int index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_PROPS_TEXT, "node props text index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_PROPS_REAL, "node props real index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_PROPS_BOOL, "node props bool index") < 0) return -1;
    
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGE_PROPS_INT, "edge props int index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGE_PROPS_TEXT, "edge props text index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGE_PROPS_REAL, "edge props real index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGE_PROPS_BOOL, "edge props bool index") < 0) return -1;

    /* Create JSON property indexes */
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_NODE_PROPS_JSON, "node props json index") < 0) return -1;
    if (execute_ddl(manager->db, CYPHER_SCHEMA_INDEX_EDGE_PROPS_JSON, "edge props json index") < 0) return -1;

    return 0;
}

int cypher_schema_initialize(cypher_schema_manager *manager)
{
    if (!manager) {
        return -1;
    }
    
    CYPHER_DEBUG("Initializing schema");

    /* Check schema version via PRAGMA user_version */
    {
        sqlite3_stmt *ver_stmt;
        int rc = sqlite3_prepare_v2(manager->db, "PRAGMA user_version", -1, &ver_stmt, NULL);
        if (rc == SQLITE_OK && sqlite3_step(ver_stmt) == SQLITE_ROW) {
            int db_version = sqlite3_column_int(ver_stmt, 0);
            sqlite3_finalize(ver_stmt);

            if (db_version > GRAPHQLITE_SCHEMA_VERSION) {
                CYPHER_DEBUG("Schema version %d is newer than supported %d",
                             db_version, GRAPHQLITE_SCHEMA_VERSION);
                return -1;  /* Database created by newer version */
            }

            if (db_version > 0 && db_version < GRAPHQLITE_SCHEMA_VERSION) {
                CYPHER_DEBUG("Migrating schema from version %d to %d",
                             db_version, GRAPHQLITE_SCHEMA_VERSION);
                /* Future migration steps go here */
            }
        } else {
            if (ver_stmt) sqlite3_finalize(ver_stmt);
        }
    }

    /* Create all tables */
    if (cypher_schema_create_tables(manager) < 0) {
        return -1;
    }
    
    /* Create all indexes */
    if (cypher_schema_create_indexes(manager) < 0) {
        return -1;
    }

    /* Run ANALYZE to update query planner statistics if needed */
    /* Check if statistics already exist to avoid expensive re-analysis */
    sqlite3_stmt *check_stmt;
    bool needs_analyze = true;
    int rc = sqlite3_prepare_v2(manager->db,
        "SELECT 1 FROM sqlite_stat1 WHERE tbl = 'edges' LIMIT 1", -1, &check_stmt, NULL);
    if (rc == SQLITE_OK) {
        if (sqlite3_step(check_stmt) == SQLITE_ROW) {
            needs_analyze = false;
            CYPHER_DEBUG("Statistics already exist, skipping ANALYZE");
        }
        sqlite3_finalize(check_stmt);
    }

    if (needs_analyze) {
        rc = sqlite3_exec(manager->db, "ANALYZE", NULL, NULL, NULL);
        if (rc != SQLITE_OK) {
            CYPHER_DEBUG("ANALYZE failed: %s", sqlite3_errmsg(manager->db));
            /* Non-fatal - continue without statistics */
        } else {
            CYPHER_DEBUG("ANALYZE completed successfully");
        }
    }

    /* Now prepare the property key cache statements */
    if (prepare_property_key_cache_statements(manager->key_cache, manager->db) < 0) {
        return -1;
    }
    
    /* Stamp schema version */
    {
        char ver_sql[64];
        snprintf(ver_sql, sizeof(ver_sql), "PRAGMA user_version = %d", GRAPHQLITE_SCHEMA_VERSION);
        sqlite3_exec(manager->db, ver_sql, NULL, NULL, NULL);
    }

    manager->schema_initialized = true;
    CYPHER_DEBUG("Schema initialization complete (version %d)", GRAPHQLITE_SCHEMA_VERSION);
    
    return 0;
}

bool cypher_schema_is_initialized(cypher_schema_manager *manager)
{
    return manager && manager->schema_initialized;
}

/* Property type inference */
property_type cypher_schema_infer_property_type(const char *value_str)
{
    if (!value_str || strlen(value_str) == 0) {
        return PROP_TYPE_TEXT;
    }
    
    /* Check for boolean */
    if (strcmp(value_str, "true") == 0 || strcmp(value_str, "false") == 0) {
        return PROP_TYPE_BOOLEAN;
    }
    
    /* Check for integer */
    char *endptr;
    strtol(value_str, &endptr, 10);
    if (*endptr == '\0') {
        return PROP_TYPE_INTEGER;
    }
    
    /* Check for real */
    strtod(value_str, &endptr);
    if (*endptr == '\0') {
        return PROP_TYPE_REAL;
    }
    
    /* Default to text */
    return PROP_TYPE_TEXT;
}

const char* cypher_schema_property_type_name(property_type type)
{
    switch (type) {
        case PROP_TYPE_INTEGER: return "INTEGER";
        case PROP_TYPE_TEXT:    return "TEXT";
        case PROP_TYPE_REAL:    return "REAL";
        case PROP_TYPE_BOOLEAN: return "BOOLEAN";
        case PROP_TYPE_JSON:    return "JSON";
        default:                return "UNKNOWN";
    }
}

/* Insert a key at the head of its slot chain (perf review: the cache used
 * to hold one entry per slot and replaced it on every collision, so two
 * hot keys sharing a slot missed alternately). */
static void key_cache_insert(property_key_cache *cache, const char *key, int key_id)
{
    if (cache->bypass) return;
    property_key_entry *entry = malloc(sizeof(property_key_entry));
    if (!entry) return;
    entry->key_id = key_id;
    entry->key_string = strdup(key);
    if (!entry->key_string) { free(entry); return; }
    entry->last_used = time(NULL);
    entry->usage_count = 1;
    int slot = hash_string(key) % cache->slot_count;
    entry->next = cache->slots[slot];
    cache->slots[slot] = entry;
    cache->total_entries++;
}

int cypher_schema_get_property_key_id(cypher_schema_manager *manager, const char *key)
{
    if (!manager || !manager->key_cache || !key) {
        return -1;
    }
    
    property_key_cache *cache = manager->key_cache;
    
    /* Calculate hash slot */
    unsigned long hash = hash_string(key);
    int slot = hash % cache->slot_count;
    
    /* Check cache first */
    for (property_key_entry *entry = cache->slots[slot]; entry; entry = entry->next) {
        if (entry->key_string && strcmp(entry->key_string, key) == 0) {
            cache->cache_hits++;
            entry->usage_count++;
            entry->last_used = time(NULL);
            CYPHER_DEBUG("Property key cache hit for '%s' -> id %d", key, entry->key_id);
            return entry->key_id;
        }
    }
    
    /* Cache miss - query database */
    cache->cache_misses++;

    /* Perf review F9: prepared once per manager */
    sqlite3_stmt *lookup_stmt = sm_stmt(manager, &manager->ps_key_lookup,
                                        "SELECT id FROM property_keys WHERE key = ?");
    if (!lookup_stmt) {
        CYPHER_DEBUG("Failed to prepare property key lookup");
        return -1;
    }

    sqlite3_bind_text(lookup_stmt, 1, key, -1, SQLITE_TRANSIENT);

    int key_id = -1;
    if (sqlite3_step(lookup_stmt) == SQLITE_ROW) {
        key_id = sqlite3_column_int(lookup_stmt, 0);
        key_cache_insert(cache, key, key_id);

        CYPHER_DEBUG("Property key '%s' found in DB -> id %d", key, key_id);
    }

    sqlite3_reset(lookup_stmt);
    return key_id;
}

int cypher_schema_ensure_property_key(cypher_schema_manager *manager, const char *key)
{
    if (!manager || !manager->key_cache || !key) {
        return -1;
    }
    
    /* First try to get existing key */
    int key_id = cypher_schema_get_property_key_id(manager, key);
    if (key_id >= 0) {
        return key_id;
    }
    
    /* Key doesn't exist - create it */
    property_key_cache *cache = manager->key_cache;

    /* Perf review F9: prepared once per manager */
    sqlite3_stmt *insert_stmt = sm_stmt(manager, &manager->ps_key_insert,
                                        "INSERT INTO property_keys (key) VALUES (?)");
    if (!insert_stmt) {
        CYPHER_DEBUG("Failed to prepare property key insert");
        return -1;
    }

    sqlite3_bind_text(insert_stmt, 1, key, -1, SQLITE_TRANSIENT);

    int rc = sm_step_done(insert_stmt);

    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to insert property key '%s': %s", key, sqlite3_errmsg(manager->db));
        return -1;
    }
    
    /* Get the new key ID */
    key_id = (int)sqlite3_last_insert_rowid(manager->db);
    cache->key_insertions++;
    
    /* Add to cache */
    key_cache_insert(cache, key, key_id);

    CYPHER_DEBUG("Created new property key '%s' -> id %d", key, key_id);
    
    return key_id;
}

const char* cypher_schema_get_property_key_name(cypher_schema_manager *manager, int key_id)
{
    if (!manager || !manager->key_cache || key_id < 0) {
        return NULL;
    }
    
    property_key_cache *cache = manager->key_cache;
    
    /* Search cache first */
    for (int i = 0; i < cache->slot_count; i++) {
        for (property_key_entry *entry = cache->slots[i]; entry; entry = entry->next) {
            if (entry->key_id != key_id) continue;
            entry->usage_count++;
            entry->last_used = time(NULL);
            cache->cache_hits++;
            return entry->key_string;
        }
    }
    
    /* Not in cache - this function doesn't populate cache for reverse lookups */
    /* since they're typically less common than forward lookups */
    cache->cache_misses++;
    
    /* For now, return NULL - could implement DB lookup if needed */
    CYPHER_DEBUG("Property key name lookup for id %d not in cache", key_id);
    return NULL;
}

int cypher_schema_create_node(cypher_schema_manager *manager)
{
    if (!manager || !manager->db) {
        return -1;
    }
    
    /* Insert into nodes table (perf review F9: prepared, not sqlite3_exec) */
    sqlite3_stmt *stmt = sm_stmt(manager, &manager->ps_insert_node, "INSERT INTO nodes DEFAULT VALUES");
    if (!stmt) return -1;
    if (sm_step_done(stmt) != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to create node: %s", sqlite3_errmsg(manager->db));
        return -1;
    }
    
    /* Get the new node ID */
    int node_id = (int)sqlite3_last_insert_rowid(manager->db);
    CYPHER_DEBUG("Created node with id %d", node_id);
    
    return node_id;
}

int cypher_schema_add_node_label(cypher_schema_manager *manager, int node_id, const char *label)
{
    if (!manager || !manager->db || !label || node_id < 0) {
        return -1;
    }
    
    /* Insert into node_labels table (perf review F9: prepared once) */
    sqlite3_stmt *stmt = sm_stmt(manager, &manager->ps_add_label,
                                 "INSERT OR IGNORE INTO node_labels (node_id, label) VALUES (?, ?)");
    if (!stmt) {
        CYPHER_DEBUG("Failed to prepare label insert statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }
    
    sqlite3_bind_int(stmt, 1, node_id);
    sqlite3_bind_text(stmt, 2, label, -1, SQLITE_TRANSIENT);
    
    int rc = sm_step_done(stmt);
    
    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to add label '%s' to node %d: %s", label, node_id, sqlite3_errmsg(manager->db));
        return -1;
    }
    
    CYPHER_DEBUG("Added label '%s' to node %d", label, node_id);
    return 0;
}

int cypher_schema_set_node_property(cypher_schema_manager *manager, 
                                   int node_id, const char *key, 
                                   property_type type, const void *value)
{
    return cypher_schema_set_node_property_ex(manager, node_id, key, type, value, false);
}

int cypher_schema_set_node_property_ex(cypher_schema_manager *manager,
                                      int node_id, const char *key,
                                      property_type type, const void *value,
                                      bool entity_is_new)
{
    if (!manager || !manager->db || !key || !value || node_id < 0) {
        return -1;
    }
    
    /* Get or create property key ID */
    int key_id = cypher_schema_ensure_property_key(manager, key);
    if (key_id < 0) {
        return -1;
    }

    int ti = prop_table_index(type);
    if (ti < 0) return -1;

    /* Clean up the property from all other type tables to avoid COALESCE
     * conflicts. Perf review F9: skipped for an entity created by this
     * statement, which cannot have rows in any typed table yet. */
    if (!entity_is_new) {
        for (int i = 0; i < 5; i++) {
            if (!manager->ps_node_prop_del[i]) {
                char cleanup_query[128];
                snprintf(cleanup_query, sizeof(cleanup_query),
                         "DELETE FROM %s WHERE node_id = ? AND key_id = ?", gql_node_prop_tables[i]);
                if (!sm_stmt(manager, &manager->ps_node_prop_del[i], cleanup_query)) continue;
            } else {
                sm_stmt(manager, &manager->ps_node_prop_del[i], NULL);
            }
            sqlite3_stmt *cleanup_stmt = manager->ps_node_prop_del[i];
            sqlite3_bind_int(cleanup_stmt, 1, node_id);
            sqlite3_bind_int(cleanup_stmt, 2, key_id);
            sm_step_done(cleanup_stmt);
        }
    }

    sqlite3_stmt *stmt;
    if (!manager->ps_node_prop_ins[ti]) {
        char sql[128];
        snprintf(sql, sizeof(sql), "INSERT OR REPLACE INTO %s (node_id, key_id, value) VALUES (?, ?, ?)",
                 gql_node_prop_tables[ti]);
        stmt = sm_stmt(manager, &manager->ps_node_prop_ins[ti], sql);
    } else {
        stmt = sm_stmt(manager, &manager->ps_node_prop_ins[ti], NULL);
    }
    if (!stmt) {
        CYPHER_DEBUG("Failed to prepare property insert statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }

    sqlite3_bind_int(stmt, 1, node_id);
    sqlite3_bind_int(stmt, 2, key_id);
    bind_prop_value(stmt, 3, type, value);
    
    int rc = sm_step_done(stmt);
    
    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to set property '%s' on node %d: %s", key, node_id, sqlite3_errmsg(manager->db));
        return -1;
    }
    
    CYPHER_DEBUG("Set property '%s' on node %d (type %s)", key, node_id, cypher_schema_property_type_name(type));
    return 0;
}

int cypher_schema_create_edge(cypher_schema_manager *manager, 
                             int source_id, int target_id, const char *type)
{
    if (!manager || !manager->db || !type) {
        return -1;
    }
    
    if (source_id < 0 || target_id < 0) {
        CYPHER_DEBUG("Invalid node IDs for edge creation: source=%d, target=%d", source_id, target_id);
        return -1;
    }
    
    /* Perf review F9: prepared once */
    sqlite3_stmt *stmt = sm_stmt(manager, &manager->ps_create_edge,
                                 "INSERT INTO edges (source_id, target_id, type) VALUES (?, ?, ?)");
    if (!stmt) {
        CYPHER_DEBUG("Failed to prepare edge insert statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }
    
    sqlite3_bind_int(stmt, 1, source_id);
    sqlite3_bind_int(stmt, 2, target_id);
    sqlite3_bind_text(stmt, 3, type, -1, SQLITE_TRANSIENT);
    
    int rc = sm_step_done(stmt);
    
    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to insert edge: %s", sqlite3_errmsg(manager->db));
        return -1;
    }
    
    int edge_id = (int)sqlite3_last_insert_rowid(manager->db);
    CYPHER_DEBUG("Created edge %d: %d -[:%s]-> %d", edge_id, source_id, type, target_id);
    
    return edge_id;
}

int cypher_schema_delete_edge(cypher_schema_manager *manager, int edge_id)
{
    if (!manager || !manager->db || edge_id < 0) {
        return -1;
    }
    
    const char *sql = "DELETE FROM edges WHERE id = ?";
    sqlite3_stmt *stmt;
    
    int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        CYPHER_DEBUG("Failed to prepare edge delete statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }
    
    sqlite3_bind_int(stmt, 1, edge_id);
    
    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    
    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to delete edge %d: %s", edge_id, sqlite3_errmsg(manager->db));
        return -1;
    }
    
    CYPHER_DEBUG("Deleted edge %d", edge_id);
    return 0;
}

int cypher_schema_set_edge_property(cypher_schema_manager *manager,
                                   int edge_id, const char *key,
                                   property_type type, const void *value)
{
    if (!manager || !manager->db || !key || !value || edge_id < 0) {
        CYPHER_DEBUG("set_edge_property: bad args manager=%p key=%p value=%p edge_id=%d", (void*)manager, (const void*)key, value, edge_id);
        return -1;
    }
    
    /* Get or create property key ID */
    int key_id = cypher_schema_ensure_property_key(manager, key);
    if (key_id < 0) {
        CYPHER_DEBUG("set_edge_property: ensure_property_key failed for '%s'", key);
        return -1;
    }

    int ti = prop_table_index(type);
    if (ti < 0) { CYPHER_DEBUG("set_edge_property: unknown type %d", (int)type); return -1; }

    sqlite3_stmt *stmt;
    if (!manager->ps_edge_prop_ins[ti]) {
        char sql[128];
        snprintf(sql, sizeof(sql), "INSERT OR REPLACE INTO %s (edge_id, key_id, value) VALUES (?, ?, ?)",
                 gql_edge_prop_tables[ti]);
        stmt = sm_stmt(manager, &manager->ps_edge_prop_ins[ti], sql);
    } else {
        stmt = sm_stmt(manager, &manager->ps_edge_prop_ins[ti], NULL);
    }
    if (!stmt) {
        CYPHER_DEBUG("Failed to prepare edge property insert statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }

    sqlite3_bind_int(stmt, 1, edge_id);
    sqlite3_bind_int(stmt, 2, key_id);
    bind_prop_value(stmt, 3, type, value);
    
    int rc = sm_step_done(stmt);
    
    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to set property '%s' on edge %d: %s", key, edge_id, sqlite3_errmsg(manager->db));
        return -1;
    }

    CYPHER_DEBUG("Set property '%s' on edge %d (type %s)", key, edge_id, cypher_schema_property_type_name(type));
    return 0;
}

/* Delete a property from a node */
int cypher_schema_delete_node_property(cypher_schema_manager *manager,
                                       int node_id, const char *property_name)
{
    if (!manager || !manager->db || !property_name || node_id < 0) {
        return -1;
    }

    /* Get the property key ID */
    int key_id = cypher_schema_get_property_key_id(manager, property_name);
    if (key_id < 0) {
        /* Property key doesn't exist, so nothing to delete */
        CYPHER_DEBUG("Property key '%s' not found, nothing to delete", property_name);
        return 0;
    }

    /* Delete from all property tables - we don't know which type it is */
    const char *tables[] = {"node_props_text", "node_props_int", "node_props_real", "node_props_bool", "node_props_json"};
    int deleted = 0;

    for (int i = 0; i < 5; i++) {
        char sql[256];
        snprintf(sql, sizeof(sql), "DELETE FROM %s WHERE node_id = ? AND key_id = ?", tables[i]);

        sqlite3_stmt *stmt;
        int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
        if (rc != SQLITE_OK) {
            continue;
        }

        sqlite3_bind_int(stmt, 1, node_id);
        sqlite3_bind_int(stmt, 2, key_id);

        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE && sqlite3_changes(manager->db) > 0) {
            deleted++;
            CYPHER_DEBUG("Deleted property '%s' from node %d (table %s)", property_name, node_id, tables[i]);
        }
        sqlite3_finalize(stmt);
    }

    return deleted > 0 ? 0 : -1;
}

/* Delete a property from an edge */
int cypher_schema_delete_edge_property(cypher_schema_manager *manager,
                                       int edge_id, const char *property_name)
{
    if (!manager || !manager->db || !property_name || edge_id < 0) {
        return -1;
    }

    /* Get the property key ID */
    int key_id = cypher_schema_get_property_key_id(manager, property_name);
    if (key_id < 0) {
        /* Property key doesn't exist, so nothing to delete */
        CYPHER_DEBUG("Property key '%s' not found, nothing to delete", property_name);
        return 0;
    }

    /* Delete from all property tables - we don't know which type it is */
    const char *tables[] = {"edge_props_text", "edge_props_int", "edge_props_real", "edge_props_bool", "edge_props_json"};
    int deleted = 0;

    for (int i = 0; i < 5; i++) {
        char sql[256];
        snprintf(sql, sizeof(sql), "DELETE FROM %s WHERE edge_id = ? AND key_id = ?", tables[i]);

        sqlite3_stmt *stmt;
        int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
        if (rc != SQLITE_OK) {
            continue;
        }

        sqlite3_bind_int(stmt, 1, edge_id);
        sqlite3_bind_int(stmt, 2, key_id);

        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE && sqlite3_changes(manager->db) > 0) {
            deleted++;
            CYPHER_DEBUG("Deleted property '%s' from edge %d (table %s)", property_name, edge_id, tables[i]);
        }
        sqlite3_finalize(stmt);
    }

    return deleted > 0 ? 0 : -1;
}

/* Delete all properties from a node (all 5 typed tables) */
int cypher_schema_delete_all_node_properties(cypher_schema_manager *manager, int node_id)
{
    if (!manager || !manager->db || node_id < 0) {
        return -1;
    }

    const char *tables[] = {"node_props_text", "node_props_int", "node_props_real", "node_props_bool", "node_props_json"};

    for (int i = 0; i < 5; i++) {
        char sql[256];
        snprintf(sql, sizeof(sql), "DELETE FROM %s WHERE node_id = ?", tables[i]);

        sqlite3_stmt *stmt;
        int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
        if (rc != SQLITE_OK) {
            continue;
        }

        sqlite3_bind_int(stmt, 1, node_id);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    CYPHER_DEBUG("Deleted all properties from node %d", node_id);
    return 0;
}

/* Delete all properties from an edge (all 5 typed tables) */
int cypher_schema_delete_all_edge_properties(cypher_schema_manager *manager, int edge_id)
{
    if (!manager || !manager->db || edge_id < 0) {
        return -1;
    }

    const char *tables[] = {"edge_props_text", "edge_props_int", "edge_props_real", "edge_props_bool", "edge_props_json"};

    for (int i = 0; i < 5; i++) {
        char sql[256];
        snprintf(sql, sizeof(sql), "DELETE FROM %s WHERE edge_id = ?", tables[i]);

        sqlite3_stmt *stmt;
        int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
        if (rc != SQLITE_OK) {
            continue;
        }

        sqlite3_bind_int(stmt, 1, edge_id);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    CYPHER_DEBUG("Deleted all properties from edge %d", edge_id);
    return 0;
}

/* Remove a label from a node */
int cypher_schema_remove_node_label(cypher_schema_manager *manager, int node_id, const char *label)
{
    if (!manager || !manager->db || !label || node_id < 0) {
        return -1;
    }

    const char *sql = "DELETE FROM node_labels WHERE node_id = ? AND label = ?";
    sqlite3_stmt *stmt;

    int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        CYPHER_DEBUG("Failed to prepare label delete statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }

    sqlite3_bind_int(stmt, 1, node_id);
    sqlite3_bind_text(stmt, 2, label, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    int changes = sqlite3_changes(manager->db);
    sqlite3_finalize(stmt);

    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to remove label '%s' from node %d: %s", label, node_id, sqlite3_errmsg(manager->db));
        return -1;
    }

    if (changes > 0) {
        CYPHER_DEBUG("Removed label '%s' from node %d", label, node_id);
        return 0;
    } else {
        CYPHER_DEBUG("Label '%s' not found on node %d", label, node_id);
        return -1;
    }
}

/* Check if a node has a specific label */
bool cypher_schema_node_has_label(cypher_schema_manager *manager, int node_id, const char *label)
{
    if (!manager || !manager->db || !label || node_id < 0) {
        return false;
    }

    const char *sql = "SELECT 1 FROM node_labels WHERE node_id = ? AND label = ? LIMIT 1";
    sqlite3_stmt *stmt;

    int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_int(stmt, 1, node_id);
    sqlite3_bind_text(stmt, 2, label, -1, SQLITE_STATIC);

    bool has_label = (sqlite3_step(stmt) == SQLITE_ROW);
    sqlite3_finalize(stmt);

    return has_label;
}

/* Delete a node (basic implementation - does not check for connected edges) */
int cypher_schema_delete_node(cypher_schema_manager *manager, int node_id)
{
    if (!manager || !manager->db || node_id < 0) {
        return -1;
    }

    const char *sql = "DELETE FROM nodes WHERE id = ?";
    sqlite3_stmt *stmt;

    int rc = sqlite3_prepare_v2(manager->db, sql, -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        CYPHER_DEBUG("Failed to prepare node delete statement: %s", sqlite3_errmsg(manager->db));
        return -1;
    }

    sqlite3_bind_int(stmt, 1, node_id);

    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc != SQLITE_DONE) {
        CYPHER_DEBUG("Failed to delete node %d: %s", node_id, sqlite3_errmsg(manager->db));
        return -1;
    }

    CYPHER_DEBUG("Deleted node %d", node_id);
    return 0;
}

/* Statistics */
void property_key_cache_stats(property_key_cache *cache,
                             long *hits, long *misses, long *insertions)
{
    if (!cache) {
        return;
    }
    
    if (hits) *hits = cache->cache_hits;
    if (misses) *misses = cache->cache_misses;
    if (insertions) *insertions = cache->key_insertions;
}