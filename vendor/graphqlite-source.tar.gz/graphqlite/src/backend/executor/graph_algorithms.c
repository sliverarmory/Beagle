/*
 * Graph Algorithms - Core Infrastructure
 *
 * CSR graph loading, algorithm detection, and result management.
 * Individual algorithms are in separate files:
 * - graph_algo_pagerank.c
 * - graph_algo_community.c
 * - graph_algo_paths.c
 * - graph_algo_centrality.c
 */

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "executor/graph_algorithms.h"
#include "executor/graph_algo_internal.h"
#include "executor/executor_internal.h"
#include "parser/cypher_ast.h"

/* Free CSR graph */
void csr_graph_free(csr_graph *graph)
{
    if (!graph) return;

    free(graph->row_ptr);
    free(graph->col_idx);
    free(graph->edge_ids);
    free(graph->node_ids);
    if (graph->user_ids) {
        for (int i = 0; i < graph->node_count; i++) {
            free(graph->user_ids[i]);
        }
        free(graph->user_ids);
    }
    free(graph->node_idx);
    free(graph->in_row_ptr);
    free(graph->in_col_idx);
    free(graph->user_hash);
    free(graph);
}

/* Build the user-id -> index hash (perf review). Best effort: on OOM the
 * lookups fall back to a linear scan. */
static void csr_build_user_hash(csr_graph *graph)
{
    if (!graph || !graph->user_ids || graph->node_count <= 0) return;
    int size = 16;
    while (size < graph->node_count * 2) size <<= 1;
    int *table = malloc((size_t)size * sizeof(int));
    if (!table) return;
    for (int i = 0; i < size; i++) table[i] = -1;
    unsigned int mask = (unsigned int)size - 1u;
    for (int i = 0; i < graph->node_count; i++) {
        if (!graph->user_ids[i]) continue;
        unsigned int h = csr_hash_str(graph->user_ids[i]) & mask;
        while (table[h] >= 0) {
            /* keep the first node for a duplicated user id */
            if (strcmp(graph->user_ids[table[h]], graph->user_ids[i]) == 0) break;
            h = (h + 1u) & mask;
        }
        if (table[h] < 0) table[h] = i;
    }
    graph->user_hash = table;
    graph->user_hash_size = size;
}

/* Load graph from SQLite into CSR format */
csr_graph* csr_graph_load(sqlite3 *db)
{
    if (!db) return NULL;

    csr_graph *graph = calloc(1, sizeof(csr_graph));
    if (!graph) return NULL;

    sqlite3_stmt *stmt = NULL;
    int rc;

    /* Step 1: Count nodes and get node IDs */
    rc = sqlite3_prepare_v2(db, "SELECT id FROM nodes ORDER BY id", -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        CYPHER_DEBUG("Failed to prepare node query: %s", sqlite3_errmsg(db));
        free(graph);
        return NULL;
    }

    int node_capacity = 1024;
    graph->node_ids = malloc(node_capacity * sizeof(int));
    if (!graph->node_ids) {
        sqlite3_finalize(stmt);
        free(graph);
        return NULL;
    }

    graph->node_count = 0;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        if (graph->node_count >= node_capacity) {
            node_capacity *= 2;
            graph->node_ids = realloc(graph->node_ids, node_capacity * sizeof(int));
            if (!graph->node_ids) {
                sqlite3_finalize(stmt);
                csr_graph_free(graph);
                return NULL;
            }
        }
        graph->node_ids[graph->node_count++] = sqlite3_column_int(stmt, 0);
    }
    sqlite3_finalize(stmt);

    if (graph->node_count == 0) {
        CYPHER_DEBUG("No nodes found in graph");
        csr_graph_free(graph);
        return NULL;
    }

    CYPHER_DEBUG("Loaded %d nodes", graph->node_count);

    /* Build node ID -> index hash table.
     * Size dynamically to maintain < 50% load factor. */
    {
        int target_size = graph->node_count * 2 + 1;
        /* Find next odd number >= target_size (simple prime approximation) */
        if (target_size < HASH_TABLE_SIZE) target_size = HASH_TABLE_SIZE;
        if (target_size % 2 == 0) target_size++;
        graph->node_idx_size = target_size;
    }
    graph->node_idx = malloc(graph->node_idx_size * sizeof(int));
    if (!graph->node_idx) {
        csr_graph_free(graph);
        return NULL;
    }

    for (int i = 0; i < graph->node_idx_size; i++) {
        graph->node_idx[i] = -1;
    }

    for (int i = 0; i < graph->node_count; i++) {
        int node_id = graph->node_ids[i];
        int h = hash_int(node_id, graph->node_idx_size);
        int probe_count = 0;
        while (graph->node_idx[h] != -1) {
            h = (h + 1) % graph->node_idx_size;
            if (++probe_count >= graph->node_idx_size) {
                /* Table is full — should not happen with dynamic sizing */
                CYPHER_DEBUG("Hash table full during CSR graph load (%d nodes, table size %d)",
                             graph->node_count, graph->node_idx_size);
                csr_graph_free(graph);
                return NULL;
            }
        }
        graph->node_idx[h] = i;
    }

    /* Step 1b: Load user-defined 'id' property for each node */
    graph->user_ids = calloc(graph->node_count, sizeof(char*));
    if (graph->user_ids) {
        rc = sqlite3_prepare_v2(db,
            "SELECT np.node_id, np.value FROM node_props_text np "
            "JOIN property_keys pk ON pk.id = np.key_id AND pk.key = 'id'",
            -1, &stmt, NULL);
        if (rc == SQLITE_OK) {
            while (sqlite3_step(stmt) == SQLITE_ROW) {
                int node_id = sqlite3_column_int(stmt, 0);
                const char *user_id = (const char*)sqlite3_column_text(stmt, 1);

                int h = hash_int(node_id, graph->node_idx_size);
                while (graph->node_idx[h] != -1) {
                    int idx = graph->node_idx[h];
                    if (graph->node_ids[idx] == node_id) {
                        graph->user_ids[idx] = user_id ? strdup(user_id) : NULL;
                        break;
                    }
                    h = (h + 1) % graph->node_idx_size;
                }
            }
            sqlite3_finalize(stmt);
            csr_build_user_hash(graph);
        }
    }

    /* Step 2: Count edges per node */
    graph->row_ptr = calloc(graph->node_count + 1, sizeof(int));
    graph->in_row_ptr = calloc(graph->node_count + 1, sizeof(int));
    if (!graph->row_ptr || !graph->in_row_ptr) {
        csr_graph_free(graph);
        return NULL;
    }

    rc = sqlite3_prepare_v2(db, "SELECT source_id, target_id FROM edges", -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        csr_graph_free(graph);
        return NULL;
    }

    graph->edge_count = 0;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int source_id = sqlite3_column_int(stmt, 0);
        int target_id = sqlite3_column_int(stmt, 1);

        int h = hash_int(source_id, graph->node_idx_size);
        while (graph->node_idx[h] != -1 && graph->node_ids[graph->node_idx[h]] != source_id) {
            h = (h + 1) % graph->node_idx_size;
        }
        int source_idx = (graph->node_idx[h] != -1) ? graph->node_idx[h] : -1;

        h = hash_int(target_id, graph->node_idx_size);
        while (graph->node_idx[h] != -1 && graph->node_ids[graph->node_idx[h]] != target_id) {
            h = (h + 1) % graph->node_idx_size;
        }
        int target_idx = (graph->node_idx[h] != -1) ? graph->node_idx[h] : -1;

        if (source_idx >= 0 && target_idx >= 0) {
            graph->row_ptr[source_idx + 1]++;
            graph->in_row_ptr[target_idx + 1]++;
            graph->edge_count++;
        }
    }
    sqlite3_finalize(stmt);

    CYPHER_DEBUG("Loaded %d edges", graph->edge_count);

    /* Convert counts to cumulative offsets */
    for (int i = 1; i <= graph->node_count; i++) {
        graph->row_ptr[i] += graph->row_ptr[i - 1];
        graph->in_row_ptr[i] += graph->in_row_ptr[i - 1];
    }

    /* Step 3: Fill col_idx arrays */
    graph->col_idx = malloc(graph->edge_count * sizeof(int));
    graph->in_col_idx = malloc(graph->edge_count * sizeof(int));
    graph->edge_ids = malloc(graph->edge_count * sizeof(int));
    if (!graph->col_idx || !graph->in_col_idx || !graph->edge_ids) {
        csr_graph_free(graph);
        return NULL;
    }

    int *out_count = calloc(graph->node_count, sizeof(int));
    int *in_count = calloc(graph->node_count, sizeof(int));
    if (!out_count || !in_count) {
        free(out_count);
        free(in_count);
        csr_graph_free(graph);
        return NULL;
    }

    rc = sqlite3_prepare_v2(db, "SELECT source_id, target_id, id FROM edges", -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        free(out_count);
        free(in_count);
        csr_graph_free(graph);
        return NULL;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int source_id = sqlite3_column_int(stmt, 0);
        int target_id = sqlite3_column_int(stmt, 1);

        int h = hash_int(source_id, graph->node_idx_size);
        while (graph->node_idx[h] != -1 && graph->node_ids[graph->node_idx[h]] != source_id) {
            h = (h + 1) % graph->node_idx_size;
        }
        int source_idx = (graph->node_idx[h] != -1) ? graph->node_idx[h] : -1;

        h = hash_int(target_id, graph->node_idx_size);
        while (graph->node_idx[h] != -1 && graph->node_ids[graph->node_idx[h]] != target_id) {
            h = (h + 1) % graph->node_idx_size;
        }
        int target_idx = (graph->node_idx[h] != -1) ? graph->node_idx[h] : -1;

        if (source_idx >= 0 && target_idx >= 0) {
            int out_pos = graph->row_ptr[source_idx] + out_count[source_idx]++;
            graph->col_idx[out_pos] = target_idx;
            graph->edge_ids[out_pos] = sqlite3_column_int(stmt, 2);

            int in_pos = graph->in_row_ptr[target_idx] + in_count[target_idx]++;
            graph->in_col_idx[in_pos] = source_idx;
        }
    }
    sqlite3_finalize(stmt);

    free(out_count);
    free(in_count);

    CYPHER_DEBUG("CSR graph loaded: %d nodes, %d edges", graph->node_count, graph->edge_count);

    return graph;
}

typedef struct {
    int edge_id;
    int slot;
} csr_edge_slot;

static int csr_edge_slot_cmp(const void *a, const void *b)
{
    int x = ((const csr_edge_slot *)a)->edge_id;
    int y = ((const csr_edge_slot *)b)->edge_id;
    return (x > y) - (x < y);
}

double* csr_load_edge_weights(sqlite3 *db, const csr_graph *graph, const char *weight_prop)
{
    int m = graph->edge_count;
    double *weights = malloc((m > 0 ? m : 1) * sizeof(double));
    if (!weights) return NULL;
    for (int i = 0; i < m; i++) weights[i] = 1.0;
    if (!weight_prop || m == 0 || !graph->edge_ids) return weights;

    /* Edge rowid -> col_idx slot, sorted for bsearch. */
    csr_edge_slot *slots = malloc(m * sizeof(csr_edge_slot));
    if (!slots) {
        free(weights);
        return NULL;
    }
    for (int i = 0; i < m; i++) {
        slots[i].edge_id = graph->edge_ids[i];
        slots[i].slot = i;
    }
    qsort(slots, m, sizeof(csr_edge_slot), csr_edge_slot_cmp);

    /* Integers and floats are stored in separate tables (#122). */
    const char *sql =
        "SELECT ep.edge_id, ep.value FROM edge_props_real ep "
        "JOIN property_keys pk ON pk.id = ep.key_id WHERE pk.key = ?1 "
        "UNION ALL "
        "SELECT ep.edge_id, ep.value FROM edge_props_int ep "
        "JOIN property_keys pk ON pk.id = ep.key_id WHERE pk.key = ?1";

    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, weight_prop, -1, SQLITE_TRANSIENT);
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            csr_edge_slot key = { sqlite3_column_int(stmt, 0), 0 };
            csr_edge_slot *hit = bsearch(&key, slots, m, sizeof(csr_edge_slot), csr_edge_slot_cmp);
            if (hit) weights[hit->slot] = sqlite3_column_double(stmt, 1);
        }
        sqlite3_finalize(stmt);
    }

    free(slots);
    return weights;
}

/*
 * Resolve a function argument to a string value.
 * Handles AST_NODE_LITERAL (string) and AST_NODE_PARAMETER (via params_json).
 * Returns strdup'd string on success, NULL on failure.
 */
static char* resolve_string_arg(ast_node *node, const char *params_json)
{
    if (!node) return NULL;

    if (node->type == AST_NODE_LITERAL) {
        cypher_literal *lit = (cypher_literal *)node;
        if (lit->literal_type == LITERAL_STRING && lit->value.string) {
            return strdup(lit->value.string);
        }
        return NULL;
    }

    if (node->type == AST_NODE_PARAMETER) {
        cypher_parameter *param = (cypher_parameter *)node;
        if (!params_json || !param->name) return NULL;

        property_type ptype;
        property_value pv;
        property_value_init(&pv);
        int rc = get_param_value(params_json, param->name, &ptype, &pv);
        if (rc == 0 && ptype == PROP_TYPE_TEXT) {
            char *result = strdup(pv.as_str);
            property_value_free(&pv);
            return result;
        }
        property_value_free(&pv);
        return NULL;
    }

    return NULL;
}

/*
 * Resolve a function argument to an int value.
 * Handles AST_NODE_LITERAL (integer) and AST_NODE_PARAMETER (via params_json).
 * Returns int on success, default_value on failure.
 */
static int resolve_int_arg(ast_node *node, const char *params_json, int default_value)
{
    if (!node) return default_value;

    if (node->type == AST_NODE_LITERAL) {
        cypher_literal *lit = (cypher_literal *)node;
        if (lit && lit->base.type == AST_NODE_LITERAL && lit->literal_type == LITERAL_INTEGER) {
            return (int) lit->value.integer;
        }
        return default_value;
    }

    if (node->type == AST_NODE_PARAMETER) {
        cypher_parameter *param = (cypher_parameter *)node;
        if (!params_json || !param->name) return default_value;

        property_type ptype;
        property_value pv;
        property_value_init(&pv);
        int rc = get_param_value(params_json, param->name, &ptype, &pv);
        if (rc == 0 && ptype == PROP_TYPE_INTEGER) {
            int64_t int_buf = pv.as_int;
            property_value_free(&pv);
            if (int_buf >= INT_MIN && int_buf <= INT_MAX) {
                return (int)int_buf;
            }
        } else {
            property_value_free(&pv);
        }

        return default_value;
    }

    return default_value;
}

/*
 * Resolve a function argument to a double value.
 * Handles AST_NODE_LITERAL (double) and AST_NODE_PARAMETER (via params_json).
 * Returns double on success, default_value on failure.
 */
static double resolve_double_arg(ast_node *node, const char *params_json, double default_value)
{
    if (!node) return default_value;

    if (node->type == AST_NODE_LITERAL) {
        cypher_literal *lit = (cypher_literal *)node;
        if (lit && lit->base.type == AST_NODE_LITERAL) {
            if (lit->literal_type == LITERAL_DECIMAL) {
                return lit->value.decimal;
            } else if (lit->literal_type == LITERAL_INTEGER) {
                return (double)lit->value.integer;
            }
        }

        return default_value;
    }

    if (node->type == AST_NODE_PARAMETER) {
        cypher_parameter *param = (cypher_parameter *)node;
        if (!params_json || !param->name) return default_value;

        property_type ptype;
        property_value pv;
        property_value_init(&pv);
        int rc = get_param_value(params_json, param->name, &ptype, &pv);

        if (rc == 0 && ptype == PROP_TYPE_REAL) {
            double result = pv.as_real;
            property_value_free(&pv);
            return result;
        }

        if (rc == 0 && ptype == PROP_TYPE_INTEGER) {
            double result = (double)pv.as_int;
            property_value_free(&pv);
            return result;
        }

        property_value_free(&pv);
        return default_value;
    }

    return default_value;
}

/* Detect graph algorithm in RETURN clause */
graph_algo_params detect_graph_algorithm(cypher_return *return_clause, const char *params_json)
{
    graph_algo_params params = {0};
    params.type = GRAPH_ALGO_NONE;
    params.damping = 0.85;
    params.iterations = 20;
    params.top_k = 0;
    params.source_id = NULL;
    params.target_id = NULL;
    params.weight_prop = NULL;
    params.resolution = 1.0;

    if (!return_clause || !return_clause->items || return_clause->items->count == 0) {
        return params;
    }

    cypher_return_item *item = (cypher_return_item *)return_clause->items->items[0];
    if (!item || !item->expr || item->expr->type != AST_NODE_FUNCTION_CALL) {
        return params;
    }

    cypher_function_call *func = (cypher_function_call *)item->expr;
    if (!func->function_name) {
        return params;
    }

    /* PageRank */
    if (strcasecmp(func->function_name, "pageRank") == 0) {
        params.type = GRAPH_ALGO_PAGERANK;

        if (func->args && func->args->count >= 1) {
            params.damping = resolve_double_arg((ast_node *)func->args->items[0], params_json, params.damping);
        }
        if (func->args && func->args->count >= 2) {
            params.iterations = resolve_int_arg((ast_node *)func->args->items[1], params_json, params.iterations);
            if (params.iterations < 1) params.iterations = 1;
            if (params.iterations > 100) params.iterations = 100;
        }
        return params;
    }

    /* topPageRank */
    if (strcasecmp(func->function_name, "topPageRank") == 0) {
        params.type = GRAPH_ALGO_PAGERANK;
        params.top_k = 10;

        if (func->args && func->args->count >= 1) {
            params.top_k = resolve_int_arg((ast_node *)func->args->items[0], params_json, params.top_k);
            if (params.top_k < 1) params.top_k = 1;
            if (params.top_k > 1000) params.top_k = 1000;
        }
        if (func->args && func->args->count >= 2) {
            params.damping = resolve_double_arg((ast_node *)func->args->items[1], params_json, params.damping);
        }
        if (func->args && func->args->count >= 3) {
            params.iterations = resolve_int_arg((ast_node *)func->args->items[2], params_json, params.iterations);
            if (params.iterations < 1) params.iterations = 1;
            if (params.iterations > 100) params.iterations = 100;
        }
        return params;
    }

    /* Label Propagation */
    if (strcasecmp(func->function_name, "labelPropagation") == 0) {
        params.type = GRAPH_ALGO_LABEL_PROPAGATION;
        params.iterations = 10;

        if (func->args && func->args->count >= 1) {
            params.iterations = resolve_int_arg((ast_node *)func->args->items[0], params_json, params.iterations);
            if (params.iterations < 1) params.iterations = 1;
            if (params.iterations > 100) params.iterations = 100;
        }
        return params;
    }

    /* Shortest Path (Dijkstra) */
    if (strcasecmp(func->function_name, "dijkstra") == 0) {
        params.type = GRAPH_ALGO_DIJKSTRA;

        if (func->args && func->args->count >= 2) {
            params.source_id = resolve_string_arg((ast_node *)func->args->items[0], params_json);
            params.target_id = resolve_string_arg((ast_node *)func->args->items[1], params_json);
        }
        if (func->args && func->args->count >= 3) {
            params.weight_prop = resolve_string_arg((ast_node *)func->args->items[2], params_json);
        }
        return params;
    }

    /* Degree Centrality */
    if (strcasecmp(func->function_name, "degreeCentrality") == 0) {
        params.type = GRAPH_ALGO_DEGREE_CENTRALITY;
        return params;
    }

    /* Weakly Connected Components */
    if (strcasecmp(func->function_name, "wcc") == 0 ||
        strcasecmp(func->function_name, "connectedComponents") == 0 ||
        strcasecmp(func->function_name, "weaklyConnectedComponents") == 0) {
        params.type = GRAPH_ALGO_WCC;
        return params;
    }

    /* Strongly Connected Components */
    if (strcasecmp(func->function_name, "scc") == 0 ||
        strcasecmp(func->function_name, "stronglyConnectedComponents") == 0) {
        params.type = GRAPH_ALGO_SCC;
        return params;
    }

    /* Betweenness Centrality */
    if (strcasecmp(func->function_name, "betweennessCentrality") == 0 ||
        strcasecmp(func->function_name, "betweenness") == 0) {
        params.type = GRAPH_ALGO_BETWEENNESS_CENTRALITY;
        return params;
    }

    /* Closeness Centrality */
    if (strcasecmp(func->function_name, "closenessCentrality") == 0 ||
        strcasecmp(func->function_name, "closeness") == 0) {
        params.type = GRAPH_ALGO_CLOSENESS_CENTRALITY;
        return params;
    }

    /* Louvain Community Detection */
    if (strcasecmp(func->function_name, "louvain") == 0) {
        params.type = GRAPH_ALGO_LOUVAIN;
        params.resolution = 1.0;

        /* Optional resolution parameter */
        if (func->args && func->args->count >= 1) {
            params.resolution = resolve_double_arg((ast_node *)func->args->items[0], params_json, params.resolution);
        }
        return params;
    }

    /* Triangle Count */
    if (strcasecmp(func->function_name, "triangleCount") == 0 ||
        strcasecmp(func->function_name, "triangles") == 0) {
        params.type = GRAPH_ALGO_TRIANGLE_COUNT;
        return params;
    }

    /* A* Shortest Path */
    if (strcasecmp(func->function_name, "astar") == 0 ||
        strcasecmp(func->function_name, "aStar") == 0) {
        params.type = GRAPH_ALGO_ASTAR;

        /* astar(source, target) or astar(source, target, lat_prop, lon_prop) */
        if (func->args && func->args->count >= 2) {
            params.source_id = resolve_string_arg((ast_node *)func->args->items[0], params_json);
            params.target_id = resolve_string_arg((ast_node *)func->args->items[1], params_json);
        }
        /* Optional: lat and lon property names for heuristic */
        if (func->args && func->args->count >= 4) {
            params.lat_prop = resolve_string_arg((ast_node *)func->args->items[2], params_json);
            params.lon_prop = resolve_string_arg((ast_node *)func->args->items[3], params_json);
        }
        return params;
    }

    /* BFS Traversal */
    if (strcasecmp(func->function_name, "bfs") == 0 ||
        strcasecmp(func->function_name, "breadthFirstSearch") == 0) {
        params.type = GRAPH_ALGO_BFS;
        params.max_depth = -1;  /* Unlimited by default */

        if (func->args && func->args->count >= 1) {
            params.source_id = resolve_string_arg((ast_node *)func->args->items[0], params_json);
        }
        if (func->args && func->args->count >= 2) {
            params.max_depth = resolve_int_arg((ast_node *)func->args->items[1], params_json, -1);
        }
        return params;
    }

    /* DFS Traversal */
    if (strcasecmp(func->function_name, "dfs") == 0 ||
        strcasecmp(func->function_name, "depthFirstSearch") == 0) {
        params.type = GRAPH_ALGO_DFS;
        params.max_depth = -1;  /* Unlimited by default */

        if (func->args && func->args->count >= 1) {
            params.source_id = resolve_string_arg((ast_node *)func->args->items[0], params_json);
        }
        if (func->args && func->args->count >= 2) {
            params.max_depth = resolve_int_arg((ast_node *)func->args->items[1], params_json, -1);
        }
        return params;
    }

    /* Node Similarity (Jaccard) */
    if (strcasecmp(func->function_name, "nodeSimilarity") == 0) {
        params.type = GRAPH_ALGO_NODE_SIMILARITY;
        params.threshold = 0.0;  /* Default: return all pairs */
        params.top_k = 0;        /* Default: no limit */
        params.source_id = NULL;
        params.target_id = NULL;

        /* Check for specific pair: nodeSimilarity('node1', 'node2') or with params */
        if (func->args && func->args->count >= 2) {
            ast_node *arg0 = (ast_node *)func->args->items[0];
            ast_node *arg1 = (ast_node *)func->args->items[1];

            /* Try resolving as string args (literals or parameters) */
            if (arg0 && (arg0->type == AST_NODE_LITERAL || arg0->type == AST_NODE_PARAMETER) &&
                arg1 && (arg1->type == AST_NODE_LITERAL || arg1->type == AST_NODE_PARAMETER)) {
                char *s0 = resolve_string_arg(arg0, params_json);
                char *s1 = resolve_string_arg(arg1, params_json);
                if (s0 && s1) {
                    params.source_id = s0;
                    params.target_id = s1;
                } else {
                    free(s0);
                    free(s1);
                }
            }
        }
        /* Check for threshold: nodeSimilarity(0.5) */
        else if (func->args && func->args->count >= 1) {
            params.threshold = resolve_double_arg((ast_node *)func->args->items[0], params_json, params.threshold);
        }

        /* nodeSimilarity(threshold, top_k): two numeric args. The pair check
         * above only sets source_id when both args resolve as strings, so
         * reaching here with count >= 2 means args[0] is the threshold and
         * args[1] is top_k (GitHub #107: threshold used to be skipped). */
        if (func->args && func->args->count >= 2 && !params.source_id) {
            params.threshold = resolve_double_arg((ast_node *)func->args->items[0], params_json, params.threshold);
            params.top_k = resolve_int_arg((ast_node *)func->args->items[1], params_json, params.top_k);
        }

        return params;
    }

    /* K-Nearest Neighbors */
    if (strcasecmp(func->function_name, "knn") == 0) {
        params.type = GRAPH_ALGO_KNN;
        params.source_id = NULL;
        params.k = 10;  /* Default k */

        /* knn(node_id, k) */
        if (func->args && func->args->count >= 1) {
            params.source_id = resolve_string_arg((ast_node *)func->args->items[0], params_json);
        }
        if (func->args && func->args->count >= 2) {
            params.k = resolve_int_arg((ast_node *)func->args->items[1], params_json, params.k);
        }

        return params;
    }

    /* Eigenvector Centrality */
    if (strcasecmp(func->function_name, "eigenvectorCentrality") == 0) {
        params.type = GRAPH_ALGO_EIGENVECTOR_CENTRALITY;
        params.iterations = 100;  /* Default iterations */

        /* Optional iterations parameter */
        if (func->args && func->args->count >= 1) {
            params.iterations = resolve_int_arg((ast_node *)func->args->items[0], params_json, params.iterations);
            if (params.iterations < 1) params.iterations = 1;
            if (params.iterations > 1000) params.iterations = 1000;
        }
        return params;
    }

    /* All Pairs Shortest Path */
    if (strcasecmp(func->function_name, "allPairsShortestPath") == 0 ||
        strcasecmp(func->function_name, "apsp") == 0) {
        params.type = GRAPH_ALGO_APSP;
        return params;
    }

    return params;
}

/* Free algorithm result */
void graph_algo_result_free(graph_algo_result *result)
{
    if (!result) return;
    free(result->error_message);
    free(result->json_result);
    free(result);
}
